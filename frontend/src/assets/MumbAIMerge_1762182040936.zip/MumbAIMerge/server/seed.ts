import { db } from "./db";
import { trails } from "@shared/schema";

const seedTrails = async () => {
  console.log("Seeding trails...");
  
  const trailsData = [
    {
      title: 'Mumbai Food Trail',
      image: '/assets/generated_images/Mumbai_street_food_scene_93c571de.png',
      difficulty: 'Easy',
      duration: '3 hours',
      rating: 4.8,
      category: 'Food',
      description: 'Discover the best street food spots in Mumbai, from vada pav to pav bhaji',
      distance: '5 km'
    },
    {
      title: 'Heritage Walk',
      image: '/assets/generated_images/Mumbai_heritage_architecture_CST_2a60e926.png',
      difficulty: 'Medium',
      duration: '4 hours',
      rating: 4.9,
      category: 'Heritage',
      description: 'Explore Mumbai\'s colonial architecture and historical landmarks',
      distance: '8 km'
    },
    {
      title: 'Marine Drive Evening',
      image: '/assets/generated_images/Marine_Drive_sunset_promenade_4a9cf5d9.png',
      difficulty: 'Easy',
      duration: '2 hours',
      rating: 4.7,
      category: 'Scenic',
      description: 'Enjoy a peaceful evening walk along Mumbai\'s iconic waterfront',
      distance: '3 km'
    },
    {
      title: 'Beach Hopping',
      image: '/assets/generated_images/Juhu_Beach_evening_scene_8613860b.png',
      difficulty: 'Easy',
      duration: '5 hours',
      rating: 4.6,
      category: 'Beaches',
      description: 'Visit multiple beaches from Juhu to Versova in a single day',
      distance: '15 km'
    },
    {
      title: 'Nature Explorer',
      image: '/assets/generated_images/Mumbai_nature_trail_forest_843ee3a1.png',
      difficulty: 'Hard',
      duration: '6 hours',
      rating: 4.8,
      category: 'Nature',
      description: 'Trek through Sanjay Gandhi National Park and discover wildlife',
      distance: '12 km'
    },
    {
      title: 'Gateway Tour',
      image: '/assets/generated_images/Mumbai_Gateway_sunset_hero_a8b398fe.png',
      difficulty: 'Easy',
      duration: '2 hours',
      rating: 4.9,
      category: 'Heritage',
      description: 'Visit the iconic Gateway of India and surrounding attractions',
      distance: '4 km'
    },
    {
      title: 'Colaba Causeway Shopping',
      image: '/assets/generated_images/Mumbai_street_food_scene_93c571de.png',
      difficulty: 'Easy',
      duration: '3 hours',
      rating: 4.5,
      category: 'Shopping',
      description: 'Shop for souvenirs and local handicrafts at Mumbai\'s famous market',
      distance: '2 km'
    },
    {
      title: 'Bollywood Studio Tour',
      image: '/assets/generated_images/Mumbai_heritage_architecture_CST_2a60e926.png',
      difficulty: 'Medium',
      duration: '5 hours',
      rating: 4.7,
      category: 'Entertainment',
      description: 'Get behind the scenes of India\'s film industry',
      distance: '10 km'
    },
    {
      title: 'Sunset at Bandra Fort',
      image: '/assets/generated_images/Marine_Drive_sunset_promenade_4a9cf5d9.png',
      difficulty: 'Easy',
      duration: '2 hours',
      rating: 4.6,
      category: 'Scenic',
      description: 'Watch the sun set over the Arabian Sea from this historic fort',
      distance: '1 km'
    }
  ];

  const existing = await db.select().from(trails);
  
  if (existing.length === 0) {
    await db.insert(trails).values(trailsData);
    console.log(`Seeded ${trailsData.length} trails successfully!`);
  } else {
    console.log(`Database already has ${existing.length} trails. Skipping seed.`);
  }
};

seedTrails().then(() => {
  console.log("Seeding complete!");
  process.exit(0);
}).catch((error) => {
  console.error("Error seeding database:", error);
  process.exit(1);
});
