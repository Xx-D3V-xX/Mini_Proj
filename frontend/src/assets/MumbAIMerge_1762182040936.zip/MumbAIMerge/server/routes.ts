import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

declare module "express-session" {
  interface SessionData {
    userId?: string;
  }
}

export function registerRoutes(app: Express): Server {
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "mumbai-trails-secret-key-change-in-production",
      resave: false,
      saveUninitialized: false,
      store: new MemoryStore({
        checkPeriod: 86400000,
      }),
      cookie: {
        maxAge: 1000 * 60 * 60 * 24 * 7,
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
      },
    })
  );

  const authMiddleware = async (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    next();
  };

  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ error: "Username already exists" });
      }

      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ error: "Email already exists" });
      }

      const user = await storage.createUser(userData);
      
      req.session.userId = user.id;
      
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error: any) {
      console.error("Registration error:", error);
      res.status(400).json({ error: error.message || "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;

      if (!username || !password) {
        return res.status(400).json({ error: "Username and password required" });
      }

      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const isValid = await storage.verifyPassword(password, user.password);
      if (!isValid) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      req.session.userId = user.id;
      
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error: any) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      res.json({ success: true });
    });
  });

  app.get("/api/auth/me", authMiddleware, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  app.get("/api/trails", async (req, res) => {
    try {
      const trails = await storage.getAllTrails();
      res.json({ trails });
    } catch (error) {
      console.error("Error fetching trails:", error);
      res.status(500).json({ error: "Failed to fetch trails" });
    }
  });

  app.get("/api/trails/:id", async (req, res) => {
    try {
      const trail = await storage.getTrail(req.params.id);
      if (!trail) {
        return res.status(404).json({ error: "Trail not found" });
      }
      res.json({ trail });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch trail" });
    }
  });

  app.get("/api/itineraries", authMiddleware, async (req, res) => {
    try {
      const itineraries = await storage.getItinerariesByUserId(req.session.userId!);
      res.json({ itineraries });
    } catch (error) {
      console.error("Error fetching itineraries:", error);
      res.status(500).json({ error: "Failed to fetch itineraries" });
    }
  });

  app.post("/api/itineraries", authMiddleware, async (req, res) => {
    try {
      const itinerary = await storage.createItinerary({
        ...req.body,
        userId: req.session.userId!,
      });
      res.json({ itinerary });
    } catch (error: any) {
      console.error("Error creating itinerary:", error);
      res.status(400).json({ error: error.message || "Failed to create itinerary" });
    }
  });

  app.patch("/api/itineraries/:id", authMiddleware, async (req, res) => {
    try {
      const itinerary = await storage.updateItinerary(req.params.id, req.body);
      if (!itinerary) {
        return res.status(404).json({ error: "Itinerary not found" });
      }
      res.json({ itinerary });
    } catch (error) {
      res.status(500).json({ error: "Failed to update itinerary" });
    }
  });

  app.delete("/api/itineraries/:id", authMiddleware, async (req, res) => {
    try {
      await storage.deleteItinerary(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete itinerary" });
    }
  });

  app.get("/api/history", authMiddleware, async (req, res) => {
    try {
      const history = await storage.getVisitHistoryByUserId(req.session.userId!);
      res.json({ history });
    } catch (error) {
      console.error("Error fetching history:", error);
      res.status(500).json({ error: "Failed to fetch history" });
    }
  });

  app.post("/api/history", authMiddleware, async (req, res) => {
    try {
      const history = await storage.createVisitHistory({
        ...req.body,
        userId: req.session.userId!,
      });
      res.json({ history });
    } catch (error: any) {
      console.error("Error creating history:", error);
      res.status(400).json({ error: error.message || "Failed to create history" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
