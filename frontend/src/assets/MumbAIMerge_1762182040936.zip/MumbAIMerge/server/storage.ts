import { db } from "./db";
import { users, itineraries, visitHistory, trails } from "@shared/schema";
import type { User, InsertUser, Itinerary, VisitHistory, Trail } from "@shared/schema";
import { eq, and } from "drizzle-orm";
import * as bcrypt from "bcrypt";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  verifyPassword(password: string, hashedPassword: string): Promise<boolean>;
  
  getItinerariesByUserId(userId: string): Promise<Itinerary[]>;
  getItinerary(id: string): Promise<Itinerary | undefined>;
  createItinerary(itinerary: Omit<Itinerary, 'id' | 'createdAt'>): Promise<Itinerary>;
  updateItinerary(id: string, itinerary: Partial<Itinerary>): Promise<Itinerary | undefined>;
  deleteItinerary(id: string): Promise<void>;
  
  getVisitHistoryByUserId(userId: string): Promise<VisitHistory[]>;
  createVisitHistory(history: Omit<VisitHistory, 'id' | 'createdAt'>): Promise<VisitHistory>;
  
  getAllTrails(): Promise<Trail[]>;
  getTrail(id: string): Promise<Trail | undefined>;
  getTrailsByCategory(category: string): Promise<Trail[]>;
  createTrail(trail: Omit<Trail, 'id' | 'createdAt'>): Promise<Trail>;
}

export class DbStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const [user] = await db.insert(users).values({
      ...insertUser,
      password: hashedPassword,
    }).returning();
    return user;
  }

  async verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
    return bcrypt.compare(password, hashedPassword);
  }

  async getItinerariesByUserId(userId: string): Promise<Itinerary[]> {
    return db.select().from(itineraries).where(eq(itineraries.userId, userId));
  }

  async getItinerary(id: string): Promise<Itinerary | undefined> {
    const [itinerary] = await db.select().from(itineraries).where(eq(itineraries.id, id));
    return itinerary;
  }

  async createItinerary(itinerary: Omit<Itinerary, 'id' | 'createdAt'>): Promise<Itinerary> {
    const [created] = await db.insert(itineraries).values(itinerary).returning();
    return created;
  }

  async updateItinerary(id: string, itinerary: Partial<Itinerary>): Promise<Itinerary | undefined> {
    const [updated] = await db.update(itineraries)
      .set(itinerary)
      .where(eq(itineraries.id, id))
      .returning();
    return updated;
  }

  async deleteItinerary(id: string): Promise<void> {
    await db.delete(itineraries).where(eq(itineraries.id, id));
  }

  async getVisitHistoryByUserId(userId: string): Promise<VisitHistory[]> {
    return db.select().from(visitHistory).where(eq(visitHistory.userId, userId));
  }

  async createVisitHistory(history: Omit<VisitHistory, 'id' | 'createdAt'>): Promise<VisitHistory> {
    const [created] = await db.insert(visitHistory).values(history).returning();
    return created;
  }

  async getAllTrails(): Promise<Trail[]> {
    return db.select().from(trails);
  }

  async getTrail(id: string): Promise<Trail | undefined> {
    const [trail] = await db.select().from(trails).where(eq(trails.id, id));
    return trail;
  }

  async getTrailsByCategory(category: string): Promise<Trail[]> {
    return db.select().from(trails).where(eq(trails.category, category));
  }

  async createTrail(trail: Omit<Trail, 'id' | 'createdAt'>): Promise<Trail> {
    const [created] = await db.insert(trails).values(trail).returning();
    return created;
  }
}

export const storage = new DbStorage();
