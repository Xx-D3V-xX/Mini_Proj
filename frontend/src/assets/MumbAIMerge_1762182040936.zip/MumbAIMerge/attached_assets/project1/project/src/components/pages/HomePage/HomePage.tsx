import React from 'react';
import { DistrictGrid } from '../../home/DistrictGrid/DistrictGrid';
import { HeroSection } from '../../home/HeroSection/HeroSection';
import { StatsSection } from '../../home/StatsSection/StatsSection';
import './HomePage.css';

interface HomePageProps {
  onDistrictClick: (districtId: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onDistrictClick }) => {
  return (
    <div className="homepage">
      <HeroSection />
      <StatsSection />
      <DistrictGrid onDistrictClick={onDistrictClick} />
    </div>
  );
};