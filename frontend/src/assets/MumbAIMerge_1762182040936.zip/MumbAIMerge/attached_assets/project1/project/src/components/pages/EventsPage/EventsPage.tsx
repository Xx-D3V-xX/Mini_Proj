import React from 'react';
import { Calendar, MapPin, Clock, Users } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { EventCarousel } from '../../events/EventCarousel/EventCarousel';
import './EventsPage.css';

export const EventsPage: React.FC = () => {
  const featuredEvents = [
    {
      id: 1,
      title: "Mumbai Music Festival",
      date: "Dec 15-17, 2024",
      location: "MMRDA Grounds",
      image: "https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "Music",
      price: "₹1,500"
    },
    {
      id: 2,
      title: "Art Exhibition: Modern Mumbai",
      date: "Dec 20, 2024",
      location: "Jehangir Art Gallery",
      image: "https://images.pexels.com/photos/1839919/pexels-photo-1839919.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "Art",
      price: "₹300"
    },
    {
      id: 3,
      title: "Food Truck Festival",
      date: "Dec 22-24, 2024",
      location: "Bandra Kurla Complex",
      image: "https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "Food",
      price: "Free"
    }
  ];

  const upcomingEvents = [
    {
      id: 4,
      title: "Stand-up Comedy Night",
      date: "Tonight, 8 PM",
      location: "Canvas Laugh Club",
      attendees: 120,
      category: "Comedy"
    },
    {
      id: 5,
      title: "Bollywood Dance Workshop",
      date: "Tomorrow, 6 PM",
      location: "Shiamak Davar Studio",
      attendees: 45,
      category: "Dance"
    },
    {
      id: 6,
      title: "Photography Walk",
      date: "Dec 18, 7 AM",
      location: "Marine Drive",
      attendees: 30,
      category: "Photography"
    }
  ];

  return (
    <div className="events-page">
      <div className="events-container">
        {/* Hero Section */}
        <div className="events-hero">
          <h1 className="events-title">Events in Mumbai</h1>
          <p className="events-subtitle">Discover concerts, shows, and happenings around the city</p>
        </div>

        {/* Featured Events Carousel */}
        <section className="featured-events-section">
          <h2 className="section-title">Featured Events</h2>
          <EventCarousel events={featuredEvents} />
        </section>

        {/* Upcoming Events */}
        <section className="upcoming-events-section">
          <h2 className="section-title">Happening Soon</h2>
          <div className="upcoming-events-grid">
            {upcomingEvents.map((event) => (
              <Card key={event.id} hover={true} className="upcoming-event-card">
                <div className="event-content">
                  <div className="event-header">
                    <h3 className="event-name">{event.title}</h3>
                    <span className="event-category">{event.category}</span>
                  </div>
                  
                  <div className="event-details">
                    <div className="event-detail">
                      <Clock className="w-4 h-4 text-gray-400" />
                      <span>{event.date}</span>
                    </div>
                    <div className="event-detail">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span>{event.location}</span>
                    </div>
                    <div className="event-detail">
                      <Users className="w-4 h-4 text-gray-400" />
                      <span>{event.attendees} attending</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* Categories */}
        <section className="categories-section">
          <h2 className="section-title">Browse by Category</h2>
          <div className="categories-scroll">
            {['Music', 'Art', 'Food', 'Comedy', 'Dance', 'Theater', 'Sports', 'Workshops'].map((category) => (
              <div key={category} className="category-chip">
                {category}
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};