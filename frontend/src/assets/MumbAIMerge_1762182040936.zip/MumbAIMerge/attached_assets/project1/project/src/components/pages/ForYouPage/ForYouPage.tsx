import React from 'react';
import { HeroSection } from './sections/HeroSection/HeroSection';
import { FeaturedSection } from './sections/FeaturedSection/FeaturedSection';
import { TrendingSection } from './sections/TrendingSection/TrendingSection';
import { RecommendationsSection } from './sections/RecommendationsSection/RecommendationsSection';
import './ForYouPage.css';

export const ForYouPage: React.FC = () => {
  return (
    <div className="for-you-page">
      <HeroSection />
      <FeaturedSection />
      <TrendingSection />
      <RecommendationsSection />
    </div>
  );
};