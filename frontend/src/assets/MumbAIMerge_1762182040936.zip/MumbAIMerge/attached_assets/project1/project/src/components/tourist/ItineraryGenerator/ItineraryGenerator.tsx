import React, { useState, useEffect } from 'react';
import { Clock, MapPin, Star, Users } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { Button } from '../../common/Button/Button';
import { TouristPreferences } from '../../../types';
import './ItineraryGenerator.css';

interface ItineraryGeneratorProps {
  preferences: TouristPreferences;
  onStartExploring: () => void;
}

export const ItineraryGenerator: React.FC<ItineraryGeneratorProps> = ({ 
  preferences, 
  onStartExploring 
}) => {
  const [isGenerating, setIsGenerating] = useState(true);
  const [itinerary, setItinerary] = useState<any[]>([]);

  useEffect(() => {
    // Simulate itinerary generation
    setTimeout(() => {
      const mockItinerary = generateMockItinerary(preferences);
      setItinerary(mockItinerary);
      setIsGenerating(false);
    }, 2000);
  }, [preferences]);

  const generateMockItinerary = (prefs: TouristPreferences) => {
    const days = [];
    for (let i = 1; i <= prefs.duration; i++) {
      days.push({
        day: i,
        title: `Day ${i} - ${getDayTitle(i)}`,
        activities: getDayActivities(i, prefs)
      });
    }
    return days;
  };

  const getDayTitle = (day: number) => {
    const titles = [
      'Historic Mumbai',
      'Beach & Bollywood',
      'Local Markets & Culture',
      'Modern Mumbai',
      'Hidden Gems'
    ];
    return titles[(day - 1) % titles.length];
  };

  const getDayActivities = (day: number, prefs: TouristPreferences) => {
    const activities = [
      { time: '9:00 AM', name: 'Gateway of India', type: 'Sightseeing', duration: '1 hour' },
      { time: '11:00 AM', name: 'Colaba Causeway Shopping', type: 'Shopping', duration: '2 hours' },
      { time: '1:00 PM', name: 'Lunch at Leopold Cafe', type: 'Dining', duration: '1 hour' },
      { time: '3:00 PM', name: 'Chhatrapati Shivaji Terminus', type: 'Architecture', duration: '1 hour' },
      { time: '6:00 PM', name: 'Marine Drive Sunset', type: 'Scenic', duration: '2 hours' }
    ];
    return activities;
  };

  if (isGenerating) {
    return (
      <div className="itinerary-loading">
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <h3 className="loading-title">Creating your perfect Mumbai itinerary...</h3>
          <p className="loading-subtitle">
            Analyzing {preferences.interests?.length} interests for {preferences.duration} days
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="itinerary-section">
      <div className="itinerary-container">
        <div className="itinerary-header">
          <h2 className="itinerary-title">Your Mumbai Adventure</h2>
          <div className="itinerary-summary">
            <div className="summary-item">
              <Clock className="w-5 h-5" />
              <span>{preferences.duration} Days</span>
            </div>
            <div className="summary-item">
              <Users className="w-5 h-5" />
              <span>{preferences.groupSize} {preferences.groupSize === 1 ? 'Person' : 'People'}</span>
            </div>
            <div className="summary-item">
              <Star className="w-5 h-5" />
              <span>{preferences.budget} Budget</span>
            </div>
          </div>
        </div>
        
        <div className="itinerary-timeline">
          {itinerary.map((day, index) => (
            <Card key={day.day} className="day-card">
              <div className="day-header">
                <div className="day-number">{day.day}</div>
                <h3 className="day-title">{day.title}</h3>
              </div>
              
              <div className="day-activities">
                {day.activities.map((activity: any, actIndex: number) => (
                  <div key={actIndex} className="activity-item">
                    <div className="activity-time">{activity.time}</div>
                    <div className="activity-details">
                      <h4 className="activity-name">{activity.name}</h4>
                      <div className="activity-meta">
                        <span className="activity-type">{activity.type}</span>
                        <span className="activity-duration">{activity.duration}</span>
                      </div>
                    </div>
                    <MapPin className="w-4 h-4 text-gray-400" />
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
        
        <div className="itinerary-actions">
          <Button variant="primary" size="lg" onClick={onStartExploring}>
            Start Exploring Mumbai
          </Button>
        </div>
      </div>
    </div>
  );
};