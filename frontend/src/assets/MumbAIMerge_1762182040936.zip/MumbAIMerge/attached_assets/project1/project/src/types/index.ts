export interface User {
  id: string;
  name: string;
  email: string;
  userType?: 'tourist' | 'local';
  isLoggedIn: boolean;
}

export interface TouristPreferences {
  duration: number;
  groupSize: number;
  interests: string[];
  budget: 'budget' | 'moderate' | 'luxury';
  accommodation: string;
}

export interface District {
  id: string;
  name: string;
  description: string;
  image: string;
  highlights: string[];
}

export interface Activity {
  id: string;
  name: string;
  category: 'dining' | 'events' | 'movies' | 'activities';
  district: string;
  rating: number;
  price: string;
}