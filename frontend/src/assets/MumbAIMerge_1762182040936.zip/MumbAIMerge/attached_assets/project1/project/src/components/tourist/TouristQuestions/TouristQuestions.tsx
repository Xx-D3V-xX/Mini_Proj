import React, { useState } from 'react';
import { Calendar, Users, Heart, DollarSign } from 'lucide-react';
import { Button } from '../../common/Button/Button';
import { Card } from '../../common/Card/Card';
import { TOURIST_INTERESTS } from '../../../utils/constants';
import { TouristPreferences } from '../../../types';
import './TouristQuestions.css';

interface TouristQuestionsProps {
  onComplete: (preferences: TouristPreferences) => void;
}

export const TouristQuestions: React.FC<TouristQuestionsProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [preferences, setPreferences] = useState<Partial<TouristPreferences>>({
    interests: []
  });

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete(preferences as TouristPreferences);
    }
  };

  const handleInterestToggle = (interest: string) => {
    const currentInterests = preferences.interests || [];
    const newInterests = currentInterests.includes(interest)
      ? currentInterests.filter(i => i !== interest)
      : [...currentInterests, interest];
    
    setPreferences({ ...preferences, interests: newInterests });
  };

  const isStepComplete = () => {
    switch (currentStep) {
      case 1: return preferences.duration && preferences.duration > 0;
      case 2: return preferences.groupSize && preferences.groupSize > 0;
      case 3: return preferences.interests && preferences.interests.length > 0;
      case 4: return preferences.budget;
      default: return false;
    }
  };

  return (
    <div className="tourist-questions-section">
      <div className="tourist-questions-container">
        <div className="progress-bar">
          <div 
            className="progress-fill"
            style={{ width: `${(currentStep / 4) * 100}%` }}
          ></div>
        </div>
        
        <Card className="questions-card">
          {currentStep === 1 && (
            <div className="question-content">
              <Calendar className="question-icon text-blue-600" />
              <h3 className="question-title">How long are you staying?</h3>
              <p className="question-subtitle">This helps us plan the perfect itinerary</p>
              
              <div className="duration-options">
                {[1, 2, 3, 4, 5, 7].map(days => (
                  <button
                    key={days}
                    className={`duration-option ${preferences.duration === days ? 'selected' : ''}`}
                    onClick={() => setPreferences({ ...preferences, duration: days })}
                  >
                    {days} {days === 1 ? 'Day' : 'Days'}
                  </button>
                ))}
              </div>
            </div>
          )}
          
          {currentStep === 2 && (
            <div className="question-content">
              <Users className="question-icon text-green-600" />
              <h3 className="question-title">How many people?</h3>
              <p className="question-subtitle">Including yourself</p>
              
              <div className="group-size-container">
                <button
                  className="group-size-btn"
                  onClick={() => setPreferences({ 
                    ...preferences, 
                    groupSize: Math.max(1, (preferences.groupSize || 1) - 1)
                  })}
                >
                  -
                </button>
                <span className="group-size-display">{preferences.groupSize || 1}</span>
                <button
                  className="group-size-btn"
                  onClick={() => setPreferences({ 
                    ...preferences, 
                    groupSize: (preferences.groupSize || 1) + 1
                  })}
                >
                  +
                </button>
              </div>
            </div>
          )}
          
          {currentStep === 3 && (
            <div className="question-content">
              <Heart className="question-icon text-red-500" />
              <h3 className="question-title">What interests you?</h3>
              <p className="question-subtitle">Select all that apply</p>
              
              <div className="interests-grid">
                {TOURIST_INTERESTS.map(interest => (
                  <button
                    key={interest}
                    className={`interest-option ${
                      preferences.interests?.includes(interest) ? 'selected' : ''
                    }`}
                    onClick={() => handleInterestToggle(interest)}
                  >
                    {interest}
                  </button>
                ))}
              </div>
            </div>
          )}
          
          {currentStep === 4 && (
            <div className="question-content">
              <DollarSign className="question-icon text-yellow-600" />
              <h3 className="question-title">What's your budget?</h3>
              <p className="question-subtitle">Per person for the entire trip</p>
              
              <div className="budget-options">
                {[
                  { value: 'budget', label: 'Budget Friendly', description: '₹1,000 - ₹3,000' },
                  { value: 'moderate', label: 'Moderate', description: '₹3,000 - ₹7,000' },
                  { value: 'luxury', label: 'Luxury', description: '₹7,000+' }
                ].map(option => (
                  <button
                    key={option.value}
                    className={`budget-option ${preferences.budget === option.value ? 'selected' : ''}`}
                    onClick={() => setPreferences({ 
                      ...preferences, 
                      budget: option.value as 'budget' | 'moderate' | 'luxury'
                    })}
                  >
                    <div className="budget-label">{option.label}</div>
                    <div className="budget-description">{option.description}</div>
                  </button>
                ))}
              </div>
            </div>
          )}
          
          <div className="question-actions">
            {currentStep > 1 && (
              <Button 
                variant="outline" 
                onClick={() => setCurrentStep(currentStep - 1)}
              >
                Previous
              </Button>
            )}
            
            <Button 
              variant="primary" 
              onClick={handleNext}
              disabled={!isStepComplete()}
            >
              {currentStep === 4 ? 'Generate Itinerary' : 'Next'}
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};