import React from 'react';
import { UtensilsCrossed, Calendar, Film, MapPin } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { LOCAL_CATEGORIES } from '../../../utils/constants';
import './LocalDashboard.css';

interface LocalDashboardProps {
  onCategoryClick: (category: string) => void;
}

export const LocalDashboard: React.FC<LocalDashboardProps> = ({ onCategoryClick }) => {
  const iconMap = {
    UtensilsCrossed,
    Calendar,
    Film,
    MapPin
  };

  return (
    <div className="local-dashboard-section">
      <div className="local-dashboard-container">
        <div className="dashboard-header">
          <h2 className="dashboard-title">What's happening in Mumbai today?</h2>
          <p className="dashboard-subtitle">
            Discover new experiences in your city
          </p>
        </div>
        
        <div className="categories-grid">
          {LOCAL_CATEGORIES.map((category) => {
            const IconComponent = iconMap[category.icon as keyof typeof iconMap];
            
            return (
              <Card 
                key={category.id}
                hover={true}
                className="category-card"
                onClick={() => onCategoryClick(category.id)}
              >
                <div className="category-content">
                  <div className="category-icon">
                    <IconComponent className="w-12 h-12" />
                  </div>
                  
                  <h3 className="category-name">{category.name}</h3>
                  <p className="category-description">{category.description}</p>
                  
                  <div className="category-stats">
                    <span className="stat-item">
                      {Math.floor(Math.random() * 50 + 10)} new today
                    </span>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
        
        <div className="quick-access">
          <h3 className="quick-access-title">Quick Access</h3>
          <div className="quick-access-grid">
            <div className="quick-item">
              <span className="quick-label">Weather</span>
              <span className="quick-value">28°C Sunny</span>
            </div>
            <div className="quick-item">
              <span className="quick-label">Traffic</span>
              <span className="quick-value">Moderate</span>
            </div>
            <div className="quick-item">
              <span className="quick-label">Events Today</span>
              <span className="quick-value">12 Active</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};