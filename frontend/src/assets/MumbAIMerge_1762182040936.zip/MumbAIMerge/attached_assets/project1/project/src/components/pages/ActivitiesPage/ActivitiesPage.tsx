import React from 'react';
import { MapPin, Star, Clock, Users } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { ActivityCarousel } from '../../activities/ActivityCarousel/ActivityCarousel';
import './ActivitiesPage.css';

export const ActivitiesPage: React.FC = () => {
  const featuredActivities = [
    {
      id: 1,
      title: "Mumbai Heritage Walk",
      description: "Explore the colonial architecture of South Mumbai",
      rating: 4.7,
      duration: "3 hours",
      price: "₹800",
      image: "https://images.pexels.com/photos/3741169/pexels-photo-3741169.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "Heritage"
    },
    {
      id: 2,
      title: "Bollywood Studio Tour",
      description: "Behind-the-scenes look at film production",
      rating: 4.5,
      duration: "4 hours",
      price: "₹1,200",
      image: "https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "Entertainment"
    },
    {
      id: 3,
      title: "Street Food Tour",
      description: "Taste authentic Mumbai street food",
      rating: 4.9,
      duration: "2.5 hours",
      price: "₹600",
      image: "https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "Food"
    }
  ];

  const popularActivities = [
    {
      id: 4,
      title: "Elephanta Caves Day Trip",
      location: "Elephanta Island",
      rating: 4.6,
      participants: 156,
      category: "Adventure"
    },
    {
      id: 5,
      title: "Dharavi Slum Tour",
      location: "Dharavi",
      rating: 4.4,
      participants: 89,
      category: "Cultural"
    },
    {
      id: 6,
      title: "Mumbai by Night Tour",
      location: "Multiple Locations",
      rating: 4.8,
      participants: 234,
      category: "Sightseeing"
    }
  ];

  return (
    <div className="activities-page">
      <div className="activities-container">
        {/* Hero Section */}
        <div className="activities-hero">
          <h1 className="activities-title">Activities in Mumbai</h1>
          <p className="activities-subtitle">Fun activities and unique experiences in the city</p>
        </div>

        {/* Featured Activities Carousel */}
        <section className="featured-activities-section">
          <h2 className="section-title">Featured Experiences</h2>
          <ActivityCarousel activities={featuredActivities} />
        </section>

        {/* Popular Activities */}
        <section className="popular-activities-section">
          <h2 className="section-title">Popular Activities</h2>
          <div className="popular-activities-grid">
            {popularActivities.map((activity) => (
              <Card key={activity.id} hover={true} className="popular-activity-card">
                <div className="activity-content">
                  <div className="activity-header">
                    <h3 className="activity-name">{activity.title}</h3>
                    <span className="activity-category">{activity.category}</span>
                  </div>
                  
                  <div className="activity-details">
                    <div className="activity-detail">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span>{activity.location}</span>
                    </div>
                    <div className="activity-detail">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span>{activity.rating}</span>
                    </div>
                    <div className="activity-detail">
                      <Users className="w-4 h-4 text-gray-400" />
                      <span>{activity.participants} joined</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* Activity Types */}
        <section className="activity-types-section">
          <h2 className="section-title">Activity Types</h2>
          <div className="activity-types-scroll">
            {['Heritage', 'Adventure', 'Cultural', 'Food Tours', 'Photography', 'Workshops', 'Water Sports', 'Nightlife'].map((type) => (
              <div key={type} className="activity-type-chip">
                {type}
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};