import React from 'react';
import { Star, Clock, MapPin } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { MovieCarousel } from '../../movies/MovieCarousel/MovieCarousel';
import './MoviesPage.css';

export const MoviesPage: React.FC = () => {
  const nowShowing = [
    {
      id: 1,
      title: "Pathaan",
      genre: "Action/Thriller",
      rating: 4.2,
      duration: "146 min",
      image: "https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=800",
      theaters: 25
    },
    {
      id: 2,
      title: "Zindagi Na Milegi Dobara",
      genre: "Comedy/Drama",
      rating: 4.8,
      duration: "155 min",
      image: "https://images.pexels.com/photos/7991319/pexels-photo-7991319.jpeg?auto=compress&cs=tinysrgb&w=800",
      theaters: 18
    },
    {
      id: 3,
      title: "Mumbai Saga",
      genre: "Crime/Drama",
      rating: 3.9,
      duration: "128 min",
      image: "https://images.pexels.com/photos/7991225/pexels-photo-7991225.jpeg?auto=compress&cs=tinysrgb&w=800",
      theaters: 22
    }
  ];

  const comingSoon = [
    {
      id: 4,
      title: "Tiger 3",
      releaseDate: "Dec 25, 2024",
      genre: "Action",
      image: "https://images.pexels.com/photos/7991456/pexels-photo-7991456.jpeg?auto=compress&cs=tinysrgb&w=800"
    },
    {
      id: 5,
      title: "Dunki",
      releaseDate: "Dec 28, 2024",
      genre: "Comedy/Drama",
      image: "https://images.pexels.com/photos/7991123/pexels-photo-7991123.jpeg?auto=compress&cs=tinysrgb&w=800"
    }
  ];

  return (
    <div className="movies-page">
      <div className="movies-container">
        {/* Hero Section */}
        <div className="movies-hero">
          <h1 className="movies-title">Movies in Mumbai</h1>
          <p className="movies-subtitle">Latest movies and showtimes across the city</p>
        </div>

        {/* Now Showing Carousel */}
        <section className="now-showing-section">
          <h2 className="section-title">Now Showing</h2>
          <MovieCarousel movies={nowShowing} />
        </section>

        {/* Coming Soon */}
        <section className="coming-soon-section">
          <h2 className="section-title">Coming Soon</h2>
          <div className="coming-soon-grid">
            {comingSoon.map((movie) => (
              <Card key={movie.id} hover={true} className="coming-soon-card">
                <div className="movie-image-container">
                  <img 
                    src={movie.image} 
                    alt={movie.title}
                    className="movie-image"
                  />
                  <div className="movie-overlay">
                    <span className="release-badge">{movie.releaseDate}</span>
                  </div>
                </div>
                <div className="movie-content">
                  <h3 className="movie-title">{movie.title}</h3>
                  <p className="movie-genre">{movie.genre}</p>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* Popular Theaters */}
        <section className="theaters-section">
          <h2 className="section-title">Popular Theaters</h2>
          <div className="theaters-grid">
            {['PVR Phoenix', 'INOX Megaplex', 'Regal Cinema', 'Metro Big Cinema'].map((theater) => (
              <Card key={theater} hover={true} className="theater-card">
                <div className="theater-content">
                  <MapPin className="w-6 h-6 text-orange-500" />
                  <span className="theater-name">{theater}</span>
                </div>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};