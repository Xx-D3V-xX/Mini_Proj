import React from 'react';
import { Plane, Home, ArrowRight } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import './UserTypeSelection.css';

interface UserTypeSelectionProps {
  onUserTypeSelect: (type: 'tourist' | 'local') => void;
}

export const UserTypeSelection: React.FC<UserTypeSelectionProps> = ({ onUserTypeSelect }) => {
  return (
    <div className="user-type-section">
      <div className="user-type-container">
        <div className="user-type-header">
          <h2 className="user-type-title">Welcome to Mumbai!</h2>
          <p className="user-type-subtitle">
            Help us personalize your experience
          </p>
        </div>
        
        <div className="user-type-grid">
          <Card 
            hover={true}
            className="user-type-card"
            onClick={() => onUserTypeSelect('tourist')}
          >
            <div className="user-type-content">
              <div className="user-type-icon tourist-icon">
                <Plane className="w-12 h-12" />
              </div>
              
              <h3 className="user-type-name">I'm a Tourist</h3>
              <p className="user-type-description">
                Visiting Mumbai for the first time or planning a trip. 
                Get personalized itineraries and recommendations.
              </p>
              
              <div className="user-type-features">
                <span>✈️ Personalized Itineraries</span>
                <span>🗺️ Must-visit Locations</span>
                <span>🍽️ Local Food Recommendations</span>
              </div>
              
              <div className="user-type-action">
                <span>Get Started</span>
                <ArrowRight className="w-5 h-5" />
              </div>
            </div>
          </Card>
          
          <Card 
            hover={true}
            className="user-type-card"
            onClick={() => onUserTypeSelect('local')}
          >
            <div className="user-type-content">
              <div className="user-type-icon local-icon">
                <Home className="w-12 h-12" />
              </div>
              
              <h3 className="user-type-name">I'm a Local</h3>
              <p className="user-type-description">
                Mumbai resident looking to discover new places, 
                events, and experiences in your city.
              </p>
              
              <div className="user-type-features">
                <span>🎭 Latest Events</span>
                <span>🍕 New Restaurants</span>
                <span>🎬 Movie Showtimes</span>
              </div>
              
              <div className="user-type-action">
                <span>Explore Now</span>
                <ArrowRight className="w-5 h-5" />
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};