import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Star, Clock, MapPin } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import './MovieCarousel.css';

interface Movie {
  id: number;
  title: string;
  genre: string;
  rating: number;
  duration: string;
  image: string;
  theaters: number;
}

interface MovieCarouselProps {
  movies: Movie[];
}

export const MovieCarousel: React.FC<MovieCarouselProps> = ({ movies }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % movies.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + movies.length) % movies.length);
  };

  return (
    <div className="movie-carousel">
      <div className="carousel-container">
        <button onClick={prevSlide} className="carousel-btn carousel-btn-left">
          <ChevronLeft className="w-6 h-6" />
        </button>

        <div className="carousel-content">
          {movies.map((movie, index) => (
            <Card
              key={movie.id}
              className={`carousel-slide ${index === currentIndex ? 'active' : ''}`}
              hover={true}
            >
              <div className="movie-image-container">
                <img 
                  src={movie.image} 
                  alt={movie.title}
                  className="movie-image"
                />
                <div className="movie-overlay">
                  <div className="movie-rating">
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    <span>{movie.rating}</span>
                  </div>
                </div>
              </div>
              <div className="movie-info">
                <h3 className="movie-title">{movie.title}</h3>
                <p className="movie-genre">{movie.genre}</p>
                <div className="movie-meta">
                  <div className="movie-detail">
                    <Clock className="w-4 h-4 text-gray-400" />
                    <span>{movie.duration}</span>
                  </div>
                  <div className="movie-detail">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    <span>{movie.theaters} theaters</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <button onClick={nextSlide} className="carousel-btn carousel-btn-right">
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      <div className="carousel-indicators">
        {movies.map((_, index) => (
          <button
            key={index}
            className={`indicator ${index === currentIndex ? 'active' : ''}`}
            onClick={() => setCurrentIndex(index)}
          />
        ))}
      </div>
    </div>
  );
};