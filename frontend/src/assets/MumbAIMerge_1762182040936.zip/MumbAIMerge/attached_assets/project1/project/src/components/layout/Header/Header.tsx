import React from 'react';
import { MapPin, User, Search } from 'lucide-react';
import './Header.css';

interface HeaderProps {
  user?: { name: string; isLoggedIn: boolean };
  currentPage?: string;
  onNavigate?: (page: string) => void;
  onProfileClick?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  user, 
  currentPage = 'for-you',
  onNavigate,
  onProfileClick 
}) => {
  const navItems = [
    { id: 'for-you', label: 'For you' },
    { id: 'dining', label: 'Dining' },
    { id: 'events', label: 'Events' },
    { id: 'movies', label: 'Movies' },
    { id: 'activities', label: 'Activities' },
    { id: 'ai-planner', label: 'AI planner' }
  ];

  return (
    <header className="header">
      <div className="header-container">
        <div className="header-logo">
          <MapPin className="w-8 h-8 text-orange-500" />
          <span className="header-title">MumbAI Trails</span>
        </div>
        
        {user?.isLoggedIn && (
          <nav className="header-nav">
            {navItems.map((item) => (
              <button
                key={item.id}
                className={`nav-item ${currentPage === item.id ? 'nav-item-active' : ''}`}
                onClick={() => onNavigate?.(item.id)}
              >
                {item.label}
              </button>
            ))}
          </nav>
        )}
        
        <div className="header-right">
          {user?.isLoggedIn && (
            <div className="search-container">
              <Search className="w-5 h-5 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search for events, movies and restaurants"
                className="search-input"
              />
            </div>
          )}
          
        {user?.isLoggedIn && (
          <div className="header-user" onClick={onProfileClick}>
            <User className="w-6 h-6" />
            <span className="header-username">Hi, {user.name}</span>
          </div>
        )}
        </div>
      </div>
    </header>
  );
};