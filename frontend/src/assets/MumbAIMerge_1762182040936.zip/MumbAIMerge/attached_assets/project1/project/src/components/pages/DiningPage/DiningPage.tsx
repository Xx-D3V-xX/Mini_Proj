import React, { useState } from 'react';
import { Search, MapPin, Star, Clock, ChefHat } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { SearchModal } from '../../common/SearchModal/SearchModal';
import './DiningPage.css';

export const DiningPage: React.FC = () => {
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);

  const featuredRestaurants = [
    {
      id: 1,
      name: "Trishna",
      cuisine: "Seafood",
      rating: 4.8,
      location: "Fort",
      image: "https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=800",
      priceRange: "₹₹₹"
    },
    {
      id: 2,
      name: "Britannia & Co.",
      cuisine: "Parsi",
      rating: 4.6,
      location: "Ballard Estate",
      image: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800",
      priceRange: "₹₹"
    },
    {
      id: 3,
      name: "The Table",
      cuisine: "European",
      rating: 4.7,
      location: "Colaba",
      image: "https://images.pexels.com/photos/941861/pexels-photo-941861.jpeg?auto=compress&cs=tinysrgb&w=800",
      priceRange: "₹₹₹₹"
    }
  ];

  return (
    <div className="dining-page">
      <div className="dining-container">
        {/* Hero Search Section */}
        <div className="dining-hero">
          <Card className="search-hero-card">
            <div className="search-hero-content">
              <div className="search-hero-icon">
                <ChefHat className="w-16 h-16 text-orange-500" />
              </div>
              <h1 className="search-hero-title">Discover Restaurants</h1>
              <p className="search-hero-subtitle">Explore menus, all in one place</p>
              
              <div 
                className="search-hero-bar"
                onClick={() => setIsSearchModalOpen(true)}
              >
                <Search className="w-6 h-6 text-gray-400" />
                <span className="search-placeholder">Search for restaurants, cuisines, dishes...</span>
              </div>
              
              <div className="search-suggestions">
                <span className="suggestion-tag">Italian</span>
                <span className="suggestion-tag">Street Food</span>
                <span className="suggestion-tag">Seafood</span>
                <span className="suggestion-tag">Vegan</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Featured Restaurants */}
        <section className="featured-section">
          <h2 className="section-title">Featured Restaurants</h2>
          <div className="restaurants-grid">
            {featuredRestaurants.map((restaurant) => (
              <Card key={restaurant.id} hover={true} className="restaurant-card">
                <div className="restaurant-image-container">
                  <img 
                    src={restaurant.image} 
                    alt={restaurant.name}
                    className="restaurant-image"
                  />
                  <div className="restaurant-overlay">
                    <span className="price-badge">{restaurant.priceRange}</span>
                  </div>
                </div>
                <div className="restaurant-content">
                  <h3 className="restaurant-name">{restaurant.name}</h3>
                  <p className="restaurant-cuisine">{restaurant.cuisine}</p>
                  <div className="restaurant-meta">
                    <div className="rating">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span>{restaurant.rating}</span>
                    </div>
                    <div className="location">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span>{restaurant.location}</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* Categories */}
        <section className="categories-section">
          <h2 className="section-title">Browse by Category</h2>
          <div className="categories-scroll">
            {['Fine Dining', 'Street Food', 'Cafes', 'Bars', 'Desserts', 'Fast Food'].map((category) => (
              <div key={category} className="category-chip">
                {category}
              </div>
            ))}
          </div>
        </section>
      </div>

      <SearchModal 
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        type="restaurants"
      />
    </div>
  );
};