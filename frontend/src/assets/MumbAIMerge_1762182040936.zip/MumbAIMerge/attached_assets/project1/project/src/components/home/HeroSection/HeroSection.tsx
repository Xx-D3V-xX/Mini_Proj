import React from 'react';
import { Sparkles } from 'lucide-react';
import './HeroSection.css';

export const HeroSection: React.FC = () => {
  return (
    <section className="hero-section">
      <div className="hero-container">
        <div className="hero-content">
          <div className="hero-badge">
            <Sparkles className="w-4 h-4" />
            <span>Explore the City of Dreams</span>
          </div>
          
          <h1 className="hero-title">
            Discover Mumbai's
            <span className="hero-highlight"> Hidden Gems</span>
          </h1>
          
          <p className="hero-description">
            From bustling markets to serene beaches, iconic landmarks to local secrets. 
            Experience Mumbai like never before with personalized recommendations.
          </p>
        </div>
        
        <div className="hero-image">
          <img 
            src="https://images.pexels.com/photos/1105766/pexels-photo-1105766.jpeg?auto=compress&cs=tinysrgb&w=800"
            alt="Mumbai Skyline"
            className="hero-img"
          />
        </div>
      </div>
    </section>
  );
};