export const MUMBAI_DISTRICTS = [
  {
    id: 'south-mumbai',
    name: 'South Mumbai',
    description: 'Historic heart with iconic landmarks',
    image: 'https://images.pexels.com/photos/3741169/pexels-photo-3741169.jpeg?auto=compress&cs=tinysrgb&w=800',
    highlights: ['Gateway of India', 'Marine Drive', 'Colaba Causeway']
  },
  {
    id: 'bandra',
    name: 'Bandra',
    description: 'Trendy suburb with vibrant nightlife',
    image: 'https://images.pexels.com/photos/1108701/pexels-photo-1108701.jpeg?auto=compress&cs=tinysrgb&w=800',
    highlights: ['Linking Road', 'Carter Road', 'Mount Mary Church']
  },
  {
    id: 'juhu',
    name: 'Juhu',
    description: 'Beach paradise and Bollywood hub',
    image: 'https://images.pexels.com/photos/1007426/pexels-photo-1007426.jpeg?auto=compress&cs=tinysrgb&w=800',
    highlights: ['Juhu Beach', 'Film City', 'Street Food']
  },
  {
    id: 'andheri',
    name: 'Andheri',
    description: 'Business district with modern amenities',
    image: 'https://images.pexels.com/photos/2263436/pexels-photo-2263436.jpeg?auto=compress&cs=tinysrgb&w=800',
    highlights: ['Versova Beach', 'Infinity Mall', 'Lokhandwala']
  }
];

export const TOURIST_INTERESTS = [
  'Historical Sites',
  'Street Food',
  'Bollywood',
  'Beaches',
  'Shopping',
  'Nightlife',
  'Art & Culture',
  'Architecture',
  'Local Markets',
  'Religious Sites'
];

export const LOCAL_CATEGORIES = [
  {
    id: 'dining',
    name: 'Dining',
    icon: 'UtensilsCrossed',
    description: 'Discover new restaurants and cafes'
  },
  {
    id: 'events',
    name: 'Events',
    icon: 'Calendar',
    description: 'Find concerts, shows, and happenings'
  },
  {
    id: 'movies',
    name: 'Movies',
    icon: 'Film',
    description: 'Latest movies and showtimes'
  },
  {
    id: 'activities',
    name: 'Activities',
    icon: 'MapPin',
    description: 'Fun activities and experiences'
  }
];