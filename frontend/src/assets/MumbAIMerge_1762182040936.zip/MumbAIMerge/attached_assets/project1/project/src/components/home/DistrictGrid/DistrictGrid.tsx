import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { MUMBAI_DISTRICTS } from '../../../utils/constants';
import './DistrictGrid.css';

interface DistrictGridProps {
  onDistrictClick: (districtId: string) => void;
}

export const DistrictGrid: React.FC<DistrictGridProps> = ({ onDistrictClick }) => {
  return (
    <section className="district-grid-section">
      <div className="district-container">
        <div className="district-header">
          <h2 className="district-title">Explore Mumbai Districts</h2>
          <p className="district-subtitle">
            Each district tells a unique story of this incredible city
          </p>
        </div>
        
        <div className="district-grid">
          {MUMBAI_DISTRICTS.map((district) => (
            <Card 
              key={district.id} 
              hover={true}
              className="district-card"
              onClick={() => onDistrictClick(district.id)}
            >
              <div className="district-image-container">
                <img 
                  src={district.image}
                  alt={district.name}
                  className="district-image"
                />
                <div className="district-overlay"></div>
              </div>
              
              <div className="district-content">
                <h3 className="district-name">{district.name}</h3>
                <p className="district-description">{district.description}</p>
                
                <div className="district-highlights">
                  {district.highlights.slice(0, 2).map((highlight, index) => (
                    <span key={index} className="district-highlight">
                      {highlight}
                    </span>
                  ))}
                </div>
                
                <div className="district-action">
                  <span className="district-action-text">Explore</span>
                  <ArrowRight className="w-4 h-4 district-arrow" />
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};