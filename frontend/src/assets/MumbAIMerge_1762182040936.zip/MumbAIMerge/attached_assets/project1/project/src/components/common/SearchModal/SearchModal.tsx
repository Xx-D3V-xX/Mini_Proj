import React, { useState, useEffect } from 'react';
import { Search, X, TrendingUp } from 'lucide-react';
import './SearchModal.css';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'restaurants' | 'events' | 'movies' | 'activities';
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose, type }) => {
  const [currentPlaceholder, setCurrentPlaceholder] = useState(0);
  const [searchValue, setSearchValue] = useState('');

  const placeholders = {
    restaurants: [
      "Search for Italian restaurants in Bandra...",
      "Find vegan cafes near Marine Drive...",
      "Discover street food in Mohammed Ali Road...",
      "Look for rooftop dining in Lower Parel...",
      "Find seafood restaurants in Juhu..."
    ],
    events: [
      "Search for music concerts this weekend...",
      "Find art exhibitions in South Mumbai...",
      "Discover comedy shows tonight...",
      "Look for food festivals this month...",
      "Find dance workshops near me..."
    ],
    movies: [
      "Search for action movies in IMAX...",
      "Find Bollywood movies near Bandra...",
      "Discover late night shows...",
      "Look for movies with subtitles...",
      "Find family-friendly movies..."
    ],
    activities: [
      "Search for heritage walks in Fort...",
      "Find water sports in Juhu...",
      "Discover photography tours...",
      "Look for cooking classes...",
      "Find adventure activities..."
    ]
  };

  const trendingSearches = {
    restaurants: ["Trishna", "Leopold Cafe", "Britannia & Co", "The Table", "Khyber"],
    events: ["Mumbai Music Festival", "Art Exhibition", "Comedy Night", "Food Festival"],
    movies: ["Pathaan", "Zindagi Na Milegi Dobara", "Mumbai Saga", "Tiger 3"],
    activities: ["Heritage Walk", "Bollywood Tour", "Street Food Tour", "Elephanta Caves"]
  };

  useEffect(() => {
    if (!isOpen) return;

    const interval = setInterval(() => {
      setCurrentPlaceholder((prev) => (prev + 1) % placeholders[type].length);
    }, 2000);

    return () => clearInterval(interval);
  }, [isOpen, type, placeholders]);

  if (!isOpen) return null;

  return (
    <div className="search-modal-overlay" onClick={onClose}>
      <div className="search-modal" onClick={(e) => e.stopPropagation()}>
        <div className="search-modal-header">
          <div className="search-input-container">
            <Search className="w-6 h-6 text-gray-400" />
            <input
              type="text"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder={placeholders[type][currentPlaceholder]}
              className="search-input"
              autoFocus
            />
          </div>
          <button onClick={onClose} className="close-button">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="search-modal-content">
          <div className="trending-section">
            <div className="trending-header">
              <TrendingUp className="w-5 h-5 text-orange-500" />
              <span className="trending-title">Trending Searches</span>
            </div>
            <div className="trending-items">
              {trendingSearches[type].map((item, index) => (
                <button
                  key={index}
                  className="trending-item"
                  onClick={() => setSearchValue(item)}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          {searchValue && (
            <div className="search-results">
              <div className="results-header">
                <span className="results-title">Search Results</span>
              </div>
              <div className="no-results">
                <p className="no-results-text">Start typing to see results...</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};