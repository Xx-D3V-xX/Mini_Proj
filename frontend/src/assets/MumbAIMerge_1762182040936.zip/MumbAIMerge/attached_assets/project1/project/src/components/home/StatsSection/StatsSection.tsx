import React from 'react';
import { MapPin, Users, Star, Camera } from 'lucide-react';
import './StatsSection.css';

export const StatsSection: React.FC = () => {
  const stats = [
    { icon: MapPin, label: 'Districts', value: '24+', color: 'text-orange-500' },
    { icon: Users, label: 'Happy Visitors', value: '50k+', color: 'text-blue-600' },
    { icon: Star, label: 'Top Rated', value: '4.8', color: 'text-yellow-500' },
    { icon: Camera, label: 'Photo Spots', value: '200+', color: 'text-green-500' }
  ];

  return (
    <section className="stats-section">
      <div className="stats-container">
        {stats.map((stat, index) => (
          <div key={index} className="stat-item">
            <stat.icon className={`stat-icon ${stat.color}`} />
            <div className="stat-content">
              <div className="stat-value">{stat.value}</div>
              <div className="stat-label">{stat.label}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};