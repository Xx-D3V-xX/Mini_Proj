import React, { useState } from 'react';
import { Header } from './components/layout/Header/Header';
import { HomePage } from './components/pages/HomePage/HomePage';
import { DiningPage } from './components/pages/DiningPage/DiningPage';
import { EventsPage } from './components/pages/EventsPage/EventsPage';
import { MoviesPage } from './components/pages/MoviesPage/MoviesPage';
import { ActivitiesPage } from './components/pages/ActivitiesPage/ActivitiesPage';
import { UserTypeSelection } from './components/auth/UserTypeSelection/UserTypeSelection';
import { TouristQuestions } from './components/tourist/TouristQuestions/TouristQuestions';
import { LocalDashboard } from './components/local/LocalDashboard/LocalDashboard';
import { ItineraryGenerator } from './components/tourist/ItineraryGenerator/ItineraryGenerator';
import { User, TouristPreferences } from './types';

type AppState = 'home' | 'userTypeSelection' | 'touristQuestions' | 'localDashboard' | 'itineraryGenerator' | 'for-you' | 'dining' | 'events' | 'movies' | 'activities' | 'ai-planner';

function App() {
  const [currentState, setCurrentState] = useState<AppState>('for-you');
  const [user, setUser] = useState<User>({
    id: '1',
    name: 'Rachel',
    email: 'rachel@gmail.com',
    isLoggedIn: true
  });
  const [touristPreferences, setTouristPreferences] = useState<TouristPreferences | null>(null);

  const handleUserTypeSelect = (type: 'tourist' | 'local') => {
    setUser({ ...user, userType: type });
    
    if (type === 'tourist') {
      setCurrentState('touristQuestions');
    } else {
      setCurrentState('localDashboard');
    }
  };

  const handleTouristQuestionsComplete = (preferences: TouristPreferences) => {
    setTouristPreferences(preferences);
    setCurrentState('itineraryGenerator');
  };

  const handleStartExploring = () => {
    setCurrentState('for-you');
  };

  const handleDistrictClick = (districtId: string) => {
    console.log('District clicked:', districtId);
    // Navigate to district details
  };

  const handleCategoryClick = (category: string) => {
    console.log('Category clicked:', category);
    // Navigate to category listings
  };

  const handleNavigate = (page: string) => {
    setCurrentState(page as AppState);
  };

  const renderCurrentState = () => {
    switch (currentState) {
      case 'home':
      case 'for-you':
        return <HomePage onDistrictClick={handleDistrictClick} />;
      
      case 'dining':
        return (
          <DiningPage />
        );
      
      case 'events':
        return (
          <EventsPage />
        );
      
      case 'movies':
        return (
          <MoviesPage />
        );
      
      case 'activities':
        return (
          <ActivitiesPage />
        );
      
      case 'ai-planner':
        return (
          <UserTypeSelection onUserTypeSelect={handleUserTypeSelect} />
        );
      
      case 'userTypeSelection':
        return (
          <div className="min-h-screen bg-gray-50 py-20 px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">AI Trip Planner</h1>
              <p className="text-xl text-gray-600">Let AI create your perfect Mumbai itinerary</p>
            </div>
          </div>
        );
      
      case 'touristQuestions':
        return <TouristQuestions onComplete={handleTouristQuestionsComplete} />;
      
      case 'localDashboard':
        return <LocalDashboard onCategoryClick={handleCategoryClick} />;
      
      case 'itineraryGenerator':
        return touristPreferences ? (
          <ItineraryGenerator 
            preferences={touristPreferences} 
            onStartExploring={handleStartExploring}
          />
        ) : null;
      
      default:
        return <HomePage onDistrictClick={handleDistrictClick} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        user={user} 
        currentPage={currentState}
        onNavigate={handleNavigate}
      />
      {renderCurrentState()}
    </div>
  );
}

export default App;

