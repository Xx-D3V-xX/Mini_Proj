import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Star, Clock, DollarSign } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import './ActivityCarousel.css';

interface Activity {
  id: number;
  title: string;
  description: string;
  rating: number;
  duration: string;
  price: string;
  image: string;
  category: string;
}

interface ActivityCarouselProps {
  activities: Activity[];
}

export const ActivityCarousel: React.FC<ActivityCarouselProps> = ({ activities }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % activities.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + activities.length) % activities.length);
  };

  return (
    <div className="activity-carousel">
      <div className="carousel-container">
        <button onClick={prevSlide} className="carousel-btn carousel-btn-left">
          <ChevronLeft className="w-6 h-6" />
        </button>

        <div className="carousel-content">
          {activities.map((activity, index) => (
            <Card
              key={activity.id}
              className={`carousel-slide ${index === currentIndex ? 'active' : ''}`}
              hover={true}
            >
              <div className="activity-image-container">
                <img 
                  src={activity.image} 
                  alt={activity.title}
                  className="activity-image"
                />
                <div className="activity-overlay">
                  <span className="activity-price">{activity.price}</span>
                </div>
              </div>
              <div className="activity-info">
                <div className="activity-header">
                  <h3 className="activity-title">{activity.title}</h3>
                  <span className="activity-category">{activity.category}</span>
                </div>
                <p className="activity-description">{activity.description}</p>
                <div className="activity-meta">
                  <div className="activity-detail">
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    <span>{activity.rating}</span>
                  </div>
                  <div className="activity-detail">
                    <Clock className="w-4 h-4 text-gray-400" />
                    <span>{activity.duration}</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <button onClick={nextSlide} className="carousel-btn carousel-btn-right">
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      <div className="carousel-indicators">
        {activities.map((_, index) => (
          <button
            key={index}
            className={`indicator ${index === currentIndex ? 'active' : ''}`}
            onClick={() => setCurrentIndex(index)}
          />
        ))}
      </div>
    </div>
  );
};