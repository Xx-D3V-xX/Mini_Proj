import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar, MapPin, Star } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import './EventCarousel.css';

interface Event {
  id: number;
  title: string;
  date: string;
  location: string;
  image: string;
  category: string;
  price: string;
}

interface EventCarouselProps {
  events: Event[];
}

export const EventCarousel: React.FC<EventCarouselProps> = ({ events }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % events.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + events.length) % events.length);
  };

  return (
    <div className="event-carousel">
      <div className="carousel-container">
        <button onClick={prevSlide} className="carousel-btn carousel-btn-left">
          <ChevronLeft className="w-6 h-6" />
        </button>

        <div className="carousel-content">
          {events.map((event, index) => (
            <Card
              key={event.id}
              className={`carousel-slide ${index === currentIndex ? 'active' : ''}`}
              hover={true}
            >
              <div className="event-image-container">
                <img 
                  src={event.image} 
                  alt={event.title}
                  className="event-image"
                />
                <div className="event-overlay">
                  <span className="event-price">{event.price}</span>
                </div>
              </div>
              <div className="event-info">
                <div className="event-header">
                  <h3 className="event-title">{event.title}</h3>
                  <span className="event-category">{event.category}</span>
                </div>
                <div className="event-meta">
                  <div className="event-detail">
                    <Calendar className="w-4 h-4 text-gray-400" />
                    <span>{event.date}</span>
                  </div>
                  <div className="event-detail">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    <span>{event.location}</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <button onClick={nextSlide} className="carousel-btn carousel-btn-right">
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      <div className="carousel-indicators">
        {events.map((_, index) => (
          <button
            key={index}
            className={`indicator ${index === currentIndex ? 'active' : ''}`}
            onClick={() => setCurrentIndex(index)}
          />
        ))}
      </div>
    </div>
  );
};