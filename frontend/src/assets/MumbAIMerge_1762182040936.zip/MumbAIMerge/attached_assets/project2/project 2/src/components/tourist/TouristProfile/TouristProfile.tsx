import React, { useState } from 'react';
import { User, Settings, MapPin, Clock, Heart, DollarSign, Zap } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { Button } from '../../common/Button/Button';
import { TouristPreferences } from '../../../types';
import './TouristProfile.css';

interface TouristProfileProps {
  onProfileComplete: (preferences: TouristPreferences) => void;
  existingProfile?: TouristPreferences;
}

export const TouristProfile: React.FC<TouristProfileProps> = ({ 
  onProfileComplete, 
  existingProfile 
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [profile, setProfile] = useState<Partial<TouristPreferences>>(
    existingProfile || {
      interests: [],
      preferredCategories: []
    }
  );

  const moods = [
    { id: 'relaxed', label: 'Relaxed', icon: '🧘', description: 'Peaceful, slow-paced experiences' },
    { id: 'adventurous', label: 'Adventurous', icon: '🏔️', description: 'Thrilling, exciting activities' },
    { id: 'foodie', label: 'Foodie', icon: '🍽️', description: 'Culinary experiences and local cuisine' },
    { id: 'heritage', label: 'Heritage', icon: '🏛️', description: 'Historical sites and cultural landmarks' },
    { id: 'cultural', label: 'Cultural', icon: '🎭', description: 'Arts, museums, and local traditions' },
    { id: 'nightlife', label: 'Nightlife', icon: '🌃', description: 'Evening entertainment and social scenes' }
  ];

  const categories = [
    'Historical Sites', 'Street Food', 'Bollywood', 'Beaches', 'Shopping',
    'Nightlife', 'Art & Culture', 'Architecture', 'Local Markets', 'Religious Sites',
    'Adventure Sports', 'Photography', 'Workshops', 'Nature', 'Museums'
  ];

  const timeSlots = [
    { id: 'morning', label: 'Morning Person', description: '6 AM - 12 PM' },
    { id: 'afternoon', label: 'Afternoon Explorer', description: '12 PM - 6 PM' },
    { id: 'evening', label: 'Evening Enthusiast', description: '6 PM - 12 AM' },
    { id: 'full-day', label: 'Full Day Adventure', description: '6 AM - 12 AM' },
    { id: 'flexible', label: 'Flexible Schedule', description: 'Anytime works' }
  ];

  const handleNext = () => {
    if (currentStep < 5) {
      setCurrentStep(currentStep + 1);
    } else {
      onProfileComplete(profile as TouristPreferences);
    }
  };

  const handleCategoryToggle = (category: string) => {
    const current = profile.preferredCategories || [];
    const updated = current.includes(category)
      ? current.filter(c => c !== category)
      : [...current, category];
    setProfile({ ...profile, preferredCategories: updated });
  };

  const isStepComplete = () => {
    switch (currentStep) {
      case 1: return profile.duration && profile.groupSize;
      case 2: return profile.mood;
      case 3: return profile.preferredCategories && profile.preferredCategories.length > 0;
      case 4: return profile.budget;
      case 5: return profile.availableTime;
      default: return false;
    }
  };

  return (
    <div className="tourist-profile-section">
      <div className="tourist-profile-container">
        <div className="profile-header">
          <User className="w-12 h-12 text-orange-500" />
          <h2 className="profile-title">Create Your Travel Profile</h2>
          <p className="profile-subtitle">
            Help us personalize your Mumbai experience
          </p>
        </div>

        <div className="progress-bar">
          <div 
            className="progress-fill"
            style={{ width: `${(currentStep / 5) * 100}%` }}
          />
        </div>

        <Card className="profile-card">
          {currentStep === 1 && (
            <div className="step-content">
              <Settings className="step-icon text-blue-600" />
              <h3 className="step-title">Basic Information</h3>
              
              <div className="form-group">
                <label className="form-label">Trip Duration (days)</label>
                <div className="duration-grid">
                  {[1, 2, 3, 4, 5, 7, 10, 14].map(days => (
                    <button
                      key={days}
                      className={`duration-option ${profile.duration === days ? 'selected' : ''}`}
                      onClick={() => setProfile({ ...profile, duration: days })}
                    >
                      {days} {days === 1 ? 'Day' : 'Days'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Group Size</label>
                <div className="group-size-container">
                  <button
                    className="group-size-btn"
                    onClick={() => setProfile({ 
                      ...profile, 
                      groupSize: Math.max(1, (profile.groupSize || 1) - 1)
                    })}
                  >
                    -
                  </button>
                  <span className="group-size-display">{profile.groupSize || 1}</span>
                  <button
                    className="group-size-btn"
                    onClick={() => setProfile({ 
                      ...profile, 
                      groupSize: (profile.groupSize || 1) + 1
                    })}
                  >
                    +
                  </button>
                </div>
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="step-content">
              <Zap className="step-icon text-purple-600" />
              <h3 className="step-title">What's Your Travel Mood?</h3>
              <p className="step-subtitle">Choose the vibe that matches your travel style</p>
              
              <div className="mood-grid">
                {moods.map(mood => (
                  <button
                    key={mood.id}
                    className={`mood-option ${profile.mood === mood.id ? 'selected' : ''}`}
                    onClick={() => setProfile({ ...profile, mood: mood.id as any })}
                  >
                    <span className="mood-icon">{mood.icon}</span>
                    <span className="mood-label">{mood.label}</span>
                    <span className="mood-description">{mood.description}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="step-content">
              <Heart className="step-icon text-red-500" />
              <h3 className="step-title">Preferred Categories</h3>
              <p className="step-subtitle">Select all that interest you</p>
              
              <div className="categories-grid">
                {categories.map(category => (
                  <button
                    key={category}
                    className={`category-option ${
                      profile.preferredCategories?.includes(category) ? 'selected' : ''
                    }`}
                    onClick={() => handleCategoryToggle(category)}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
          )}

          {currentStep === 4 && (
            <div className="step-content">
              <DollarSign className="step-icon text-green-600" />
              <h3 className="step-title">Budget Range</h3>
              <p className="step-subtitle">Per person for the entire trip</p>
              
              <div className="budget-options">
                {[
                  { value: 'budget', label: 'Budget Friendly', description: '₹1,000 - ₹3,000', icon: '💰' },
                  { value: 'moderate', label: 'Moderate', description: '₹3,000 - ₹7,000', icon: '💳' },
                  { value: 'luxury', label: 'Luxury', description: '₹7,000+', icon: '💎' }
                ].map(option => (
                  <button
                    key={option.value}
                    className={`budget-option ${profile.budget === option.value ? 'selected' : ''}`}
                    onClick={() => setProfile({ 
                      ...profile, 
                      budget: option.value as 'budget' | 'moderate' | 'luxury'
                    })}
                  >
                    <span className="budget-icon">{option.icon}</span>
                    <div className="budget-info">
                      <div className="budget-label">{option.label}</div>
                      <div className="budget-description">{option.description}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {currentStep === 5 && (
            <div className="step-content">
              <Clock className="step-icon text-blue-500" />
              <h3 className="step-title">Available Time</h3>
              <p className="step-subtitle">When do you prefer to explore?</p>
              
              <div className="time-options">
                {timeSlots.map(slot => (
                  <button
                    key={slot.id}
                    className={`time-option ${profile.availableTime === slot.id ? 'selected' : ''}`}
                    onClick={() => setProfile({ 
                      ...profile, 
                      availableTime: slot.id as any
                    })}
                  >
                    <div className="time-label">{slot.label}</div>
                    <div className="time-description">{slot.description}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="step-actions">
            {currentStep > 1 && (
              <Button 
                variant="outline" 
                onClick={() => setCurrentStep(currentStep - 1)}
              >
                Previous
              </Button>
            )}
            
            <Button 
              variant="primary" 
              onClick={handleNext}
              disabled={!isStepComplete()}
            >
              {currentStep === 5 ? 'Complete Profile' : 'Next'}
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};