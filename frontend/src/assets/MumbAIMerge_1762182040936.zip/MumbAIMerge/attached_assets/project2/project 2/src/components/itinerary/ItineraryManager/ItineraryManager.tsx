import React, { useState } from 'react';
import { Save, Share2, Download, QrCode, Heart, MapPin, Clock, DollarSign } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { Button } from '../../common/Button/Button';
import { Itinerary } from '../../../types';
import './ItineraryManager.css';

interface ItineraryManagerProps {
  itinerary: Itinerary;
  onSave: (itinerary: Itinerary) => void;
  onShare: (itinerary: Itinerary) => void;
  onExportPDF: (itinerary: Itinerary) => void;
}

export const ItineraryManager: React.FC<ItineraryManagerProps> = ({
  itinerary,
  onSave,
  onShare,
  onExportPDF
}) => {
  const [isSharing, setIsSharing] = useState(false);
  const [shareLink, setShareLink] = useState('');

  const handleShare = async () => {
    setIsSharing(true);
    // Simulate API call to generate shareable link
    setTimeout(() => {
      const link = `https://mumbaitrails.com/itinerary/${itinerary.id}`;
      setShareLink(link);
      onShare(itinerary);
      setIsSharing(false);
    }, 1000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareLink);
    // Show toast notification
  };

  const generateQRCode = () => {
    // Generate QR code for the itinerary
    return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(shareLink)}`;
  };

  return (
    <div className="itinerary-manager">
      <div className="manager-container">
        {/* Itinerary Header */}
        <Card className="itinerary-header-card">
          <div className="itinerary-header">
            <div className="header-info">
              <h1 className="itinerary-title">{itinerary.title}</h1>
              <p className="itinerary-description">{itinerary.description}</p>
              
              <div className="itinerary-meta">
                <div className="meta-item">
                  <Clock className="w-5 h-5 text-gray-400" />
                  <span>{itinerary.duration} days</span>
                </div>
                <div className="meta-item">
                  <DollarSign className="w-5 h-5 text-gray-400" />
                  <span>₹{itinerary.totalCost.toLocaleString()}</span>
                </div>
                <div className="meta-item">
                  <Heart className="w-5 h-5 text-red-500" />
                  <span>{itinerary.likes} likes</span>
                </div>
              </div>
            </div>
            
            <div className="header-actions">
              <Button variant="outline" onClick={() => onSave(itinerary)}>
                <Save className="w-4 h-4 mr-2" />
                Save
              </Button>
              <Button variant="outline" onClick={handleShare} disabled={isSharing}>
                <Share2 className="w-4 h-4 mr-2" />
                {isSharing ? 'Generating...' : 'Share'}
              </Button>
              <Button variant="primary" onClick={() => onExportPDF(itinerary)}>
                <Download className="w-4 h-4 mr-2" />
                Export PDF
              </Button>
            </div>
          </div>
        </Card>

        {/* Share Modal */}
        {shareLink && (
          <Card className="share-card">
            <div className="share-content">
              <h3 className="share-title">Share Your Itinerary</h3>
              
              <div className="share-options">
                <div className="share-link">
                  <label className="share-label">Shareable Link</label>
                  <div className="link-container">
                    <input 
                      type="text" 
                      value={shareLink} 
                      readOnly 
                      className="link-input"
                    />
                    <Button variant="outline" size="sm" onClick={handleCopyLink}>
                      Copy
                    </Button>
                  </div>
                </div>
                
                <div className="qr-code">
                  <label className="share-label">QR Code</label>
                  <div className="qr-container">
                    <img 
                      src={generateQRCode()} 
                      alt="QR Code" 
                      className="qr-image"
                    />
                    <p className="qr-description">
                      Scan to view itinerary on mobile
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Itinerary Timeline */}
        <div className="itinerary-timeline">
          {itinerary.days.map((day, index) => (
            <Card key={day.day} className="day-card">
              <div className="day-header">
                <div className="day-number">{day.day}</div>
                <div className="day-info">
                  <h3 className="day-title">{day.title}</h3>
                  <div className="day-meta">
                    <span className="day-cost">₹{day.totalCost}</span>
                    <span className="day-time">{day.estimatedTravelTime}h travel</span>
                  </div>
                </div>
              </div>
              
              <div className="day-activities">
                {day.activities.map((activity, actIndex) => (
                  <div key={actIndex} className="activity-item">
                    <div className="activity-time">
                      {/* Calculate time based on activity order */}
                      {`${9 + actIndex * 2}:00`}
                    </div>
                    <div className="activity-details">
                      <h4 className="activity-name">{activity.name}</h4>
                      <div className="activity-meta">
                        <span className="activity-category">{activity.category}</span>
                        <span className="activity-duration">{activity.duration}h</span>
                        <span className="activity-price">{activity.price}</span>
                      </div>
                      <p className="activity-description">{activity.description}</p>
                    </div>
                    <div className="activity-location">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span className="location-text">{activity.district}</span>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Travel Route Info */}
              {index < itinerary.days.length - 1 && (
                <div className="travel-info">
                  <div className="travel-route">
                    <span className="travel-text">
                      Next day travel time: {itinerary.travelRoutes[index]?.estimatedTime || 30} minutes
                    </span>
                  </div>
                </div>
              )}
            </Card>
          ))}
        </div>

        {/* Weather & Traffic Info */}
        {itinerary.weatherInfo && (
          <Card className="weather-card">
            <h3 className="weather-title">Weather Forecast</h3>
            <div className="weather-info">
              <div className="weather-item">
                <span className="weather-label">Temperature</span>
                <span className="weather-value">
                  {itinerary.weatherInfo.temperature.min}° - {itinerary.weatherInfo.temperature.max}°C
                </span>
              </div>
              <div className="weather-item">
                <span className="weather-label">Condition</span>
                <span className="weather-value">{itinerary.weatherInfo.condition}</span>
              </div>
              <div className="weather-item">
                <span className="weather-label">Rainfall</span>
                <span className="weather-value">{itinerary.weatherInfo.rainfall}%</span>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};