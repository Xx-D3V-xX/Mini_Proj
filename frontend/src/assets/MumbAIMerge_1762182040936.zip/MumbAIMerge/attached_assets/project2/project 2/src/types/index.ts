export interface User {
  id: string;
  name: string;
  email: string;
  userType?: 'tourist' | 'local' | 'admin';
  isLoggedIn: boolean;
  profileComplete?: boolean;
}

export interface TouristPreferences {
  duration: number;
  groupSize: number;
  interests: string[];
  budget: 'budget' | 'moderate' | 'luxury';
  mood: 'relaxed' | 'adventurous' | 'foodie' | 'heritage' | 'cultural' | 'nightlife';
  preferredCategories: string[];
  availableTime: 'morning' | 'afternoon' | 'evening' | 'full-day' | 'flexible';
  location?: string;
}

export interface TouristProfile {
  id: string;
  userId: string;
  preferences: TouristPreferences;
  savedItineraries: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Itinerary {
  id: string;
  userId: string;
  title: string;
  description: string;
  duration: number;
  totalCost: number;
  days: ItineraryDay[];
  travelRoutes: TravelRoute[];
  weatherInfo?: WeatherInfo;
  trafficInfo?: TrafficInfo;
  shareableLink?: string;
  qrCode?: string;
  createdAt: Date;
  isPublic: boolean;
  likes: number;
  views: number;
}

export interface ItineraryDay {
  day: number;
  title: string;
  activities: Activity[];
  totalCost: number;
  estimatedTravelTime: number;
}

export interface TravelRoute {
  from: Location;
  to: Location;
  distance: number;
  estimatedTime: number;
  mode: 'walking' | 'taxi' | 'metro' | 'bus' | 'auto';
  cost: number;
}

export interface Location {
  id: string;
  name: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  address: string;
}

export interface WeatherInfo {
  date: string;
  temperature: {
    min: number;
    max: number;
  };
  condition: string;
  humidity: number;
  rainfall: number;
}

export interface TrafficInfo {
  route: string;
  congestionLevel: 'low' | 'moderate' | 'high';
  estimatedDelay: number;
  alternativeRoutes: string[];
}

export interface Analytics {
  popularSpots: {
    id: string;
    name: string;
    visits: number;
    rating: number;
  }[];
  frequentItineraries: {
    id: string;
    title: string;
    bookings: number;
  }[];
  userFeedback: {
    averageRating: number;
    totalReviews: number;
    categories: {
      [key: string]: number;
    };
  };
}

export interface District {
  id: string;
  name: string;
  description: string;
  image: string;
  highlights: string[];
  coordinates: {
    lat: number;
    lng: number;
  };
  mood: string[];
}

export interface Activity {
  id: string;
  name: string;
  category: 'dining' | 'events' | 'movies' | 'activities';
  district: string;
  rating: number;
  price: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  mood: string[];
  duration: number;
  description: string;
  images: string[];
  openingHours: {
    [key: string]: string;
  };
}