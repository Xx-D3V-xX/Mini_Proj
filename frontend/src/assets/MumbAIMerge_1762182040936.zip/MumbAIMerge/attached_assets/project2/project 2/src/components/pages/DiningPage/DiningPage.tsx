import React, { useState } from 'react';
import { Search, MapPin, Star, Clock, ChefHat, X, Phone, Globe, Heart } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { SearchModal } from '../../common/SearchModal/SearchModal';
import { Button } from '../../common/Button/Button';
import './DiningPage.css';

interface Restaurant {
  id: number;
  name: string;
  cuisine: string;
  rating: number;
  location: string;
  image: string;
  priceRange: string;
  phone?: string;
  website?: string;
  description?: string;
  openHours?: string;
  averageCost?: string;
  specialties?: string[];
}

export const DiningPage: React.FC = () => {
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);

  const featuredRestaurants: Restaurant[] = [
    {
      id: 1,
      name: "Trishna",
      cuisine: "Seafood",
      rating: 4.8,
      location: "Fort",
      image: "https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=800",
      priceRange: "₹₹₹",
      phone: "+91 22 6636 9999",
      website: "www.trishna-mumbai.com",
      description: "Award-winning seafood restaurant known for its innovative Indian coastal cuisine with a contemporary twist.",
      openHours: "12:00 PM - 3:30 PM, 7:00 PM - 11:30 PM",
      averageCost: "₹2,500 for two",
      specialties: ["Koliwada Crab", "Pepper Soft Shell Crab", "Goan Fish Curry"]
    },
    {
      id: 2,
      name: "Britannia & Co.",
      cuisine: "Parsi",
      rating: 4.6,
      location: "Ballard Estate",
      image: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800",
      priceRange: "₹₹",
      phone: "+91 22 2261 5264",
      website: "www.britannia.co.in",
      description: "Historic Parsi restaurant serving authentic Parsi cuisine since 1923. Famous for its berry pulao and caramel custard.",
      openHours: "11:30 AM - 4:00 PM",
      averageCost: "₹800 for two",
      specialties: ["Berry Pulao", "Dhansak", "Caramel Custard"]
    },
    {
      id: 3,
      name: "The Table",
      cuisine: "European",
      rating: 4.7,
      location: "Colaba",
      image: "https://images.pexels.com/photos/941861/pexels-photo-941861.jpeg?auto=compress&cs=tinysrgb&w=800",
      priceRange: "₹₹₹₹",
      phone: "+91 22 6636 9999",
      website: "www.thetable.in",
      description: "Upscale European restaurant offering contemporary cuisine with an extensive wine selection.",
      openHours: "12:00 PM - 1:00 AM",
      averageCost: "₹3,500 for two",
      specialties: ["Truffle Risotto", "Lamb Rack", "Chocolate Soufflé"]
    },
    {
      id: 4,
      name: "Leopold Cafe",
      cuisine: "Continental",
      rating: 4.3,
      location: "Colaba",
      image: "https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=800",
      priceRange: "₹₹",
      phone: "+91 22 2202 0131",
      description: "Iconic cafe and bar, a favorite among locals and tourists since 1871.",
      openHours: "8:00 AM - 12:30 AM",
      averageCost: "₹1,200 for two",
      specialties: ["Fish & Chips", "Chicken Stroganoff", "Leopold Beer"]
    },
    {
      id: 5,
      name: "Khyber",
      cuisine: "North Indian",
      rating: 4.5,
      location: "Fort",
      image: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800",
      priceRange: "₹₹₹",
      phone: "+91 22 4033 4433",
      description: "Legendary restaurant serving authentic North Indian cuisine in a rustic ambiance.",
      openHours: "12:30 PM - 3:30 PM, 7:30 PM - 11:30 PM",
      averageCost: "₹2,000 for two",
      specialties: ["Rogan Josh", "Sikandari Raan", "Dal Khyber"]
    },
    {
      id: 6,
      name: "Cafe Mocha",
      cuisine: "Italian",
      rating: 4.4,
      location: "Bandra",
      image: "https://images.pexels.com/photos/941861/pexels-photo-941861.jpeg?auto=compress&cs=tinysrgb&w=800",
      priceRange: "₹₹",
      phone: "+91 22 2640 9595",
      description: "Cozy cafe known for its coffee, desserts, and Italian fare.",
      openHours: "9:00 AM - 1:00 AM",
      averageCost: "₹1,000 for two",
      specialties: ["Tiramisu", "Pasta Arrabiata", "Mocha Coffee"]
    }
  ];

  const categories = [
    { id: 'fine-dining', name: 'Fine Dining', count: 45 },
    { id: 'street-food', name: 'Street Food', count: 120 },
    { id: 'cafes', name: 'Cafes', count: 89 },
    { id: 'bars', name: 'Bars', count: 67 },
    { id: 'desserts', name: 'Desserts', count: 34 },
    { id: 'fast-food', name: 'Fast Food', count: 156 },
    { id: 'indian', name: 'Indian', count: 200 },
    { id: 'chinese', name: 'Chinese', count: 78 },
    { id: 'italian', name: 'Italian', count: 56 },
    { id: 'continental', name: 'Continental', count: 43 },
    { id: 'seafood', name: 'Seafood', count: 67 },
    { id: 'vegetarian', name: 'Vegetarian', count: 89 }
  ];

  const getFilteredRestaurants = () => {
    if (!selectedCategory) return featuredRestaurants;
    
    // Simple filtering logic - in a real app, this would be more sophisticated
    return featuredRestaurants.filter(restaurant => {
      const categoryMap: { [key: string]: string[] } = {
        'fine-dining': ['European', 'Seafood'],
        'indian': ['Parsi', 'North Indian'],
        'continental': ['Continental', 'European'],
        'italian': ['Italian'],
        'cafes': ['Continental']
      };
      return categoryMap[selectedCategory]?.includes(restaurant.cuisine);
    });
  };

  return (
    <div className="dining-page">
      <div className="dining-container">
        {/* Hero Search Section */}
        <div className="dining-hero">
          <Card className="search-hero-card">
            <div className="search-hero-content">
              <div className="search-hero-icon">
                <ChefHat className="w-16 h-16 text-orange-500" />
              </div>
              <h1 className="search-hero-title">Discover Restaurants</h1>
              <p className="search-hero-subtitle">Explore menus, all in one place</p>
              
              <div 
                className="search-hero-bar"
                onClick={() => setIsSearchModalOpen(true)}
              >
                <Search className="w-6 h-6 text-gray-400" />
                <span className="search-placeholder">Search for restaurants, cuisines, dishes...</span>
              </div>
              
              <div className="search-suggestions">
                <span className="suggestion-tag">Italian</span>
                <span className="suggestion-tag">Street Food</span>
                <span className="suggestion-tag">Seafood</span>
                <span className="suggestion-tag">Vegan</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Featured Restaurants */}
        <section className="featured-section">
          <h2 className="section-title">
            {selectedCategory ? `${categories.find(c => c.id === selectedCategory)?.name} Restaurants` : 'Featured Restaurants'}
          </h2>
          {selectedCategory && (
            <div className="category-header">
              <Button variant="outline" onClick={() => setSelectedCategory(null)}>
                ← Back to All Restaurants
              </Button>
            </div>
          )}
          <div className="restaurants-grid">
            {getFilteredRestaurants().map((restaurant) => (
              <Card 
                key={restaurant.id} 
                hover={true} 
                className="restaurant-card"
                onClick={() => setSelectedRestaurant(restaurant)}
              >
                <div className="restaurant-image-container">
                  <img 
                    src={restaurant.image} 
                    alt={restaurant.name}
                    className="restaurant-image"
                  />
                  <div className="restaurant-overlay">
                    <span className="price-badge">{restaurant.priceRange}</span>
                  </div>
                </div>
                <div className="restaurant-content">
                  <h3 className="restaurant-name">{restaurant.name}</h3>
                  <p className="restaurant-cuisine">{restaurant.cuisine}</p>
                  <div className="restaurant-meta">
                    <div className="rating">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span>{restaurant.rating}</span>
                    </div>
                    <div className="location">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span>{restaurant.location}</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>

        {/* Categories */}
        <section className="categories-section">
          <h2 className="section-title">Browse by Category</h2>
          <div className="categories-scroll">
            {categories.map((category) => (
              <div 
                key={category.id} 
                className={`category-chip ${selectedCategory === category.id ? 'active' : ''}`}
                onClick={() => setSelectedCategory(category.id)}
              >
                <span>{category.name}</span>
                <span className="category-count">({category.count})</span>
              </div>
            ))}
          </div>
        </section>
      </div>

      <SearchModal 
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        type="restaurants"
      />

      {/* Restaurant Details Modal */}
      {selectedRestaurant && (
        <div className="restaurant-modal-overlay" onClick={() => setSelectedRestaurant(null)}>
          <div className="restaurant-modal" onClick={(e) => e.stopPropagation()}>
            <button 
              className="modal-close-btn"
              onClick={() => setSelectedRestaurant(null)}
            >
              <X className="w-6 h-6" />
            </button>
            
            <div className="modal-image-container">
              <img 
                src={selectedRestaurant.image} 
                alt={selectedRestaurant.name}
                className="modal-image"
              />
              <div className="modal-image-overlay">
                <button className="favorite-btn">
                  <Heart className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="modal-content">
              <div className="modal-header">
                <h2 className="modal-title">{selectedRestaurant.name}</h2>
                <div className="modal-rating">
                  <Star className="w-5 h-5 text-yellow-500 fill-current" />
                  <span>{selectedRestaurant.rating}</span>
                </div>
              </div>
              
              <div className="modal-details">
                <div className="detail-item">
                  <ChefHat className="w-5 h-5 text-gray-400" />
                  <span>{selectedRestaurant.cuisine}</span>
                </div>
                <div className="detail-item">
                  <MapPin className="w-5 h-5 text-gray-400" />
                  <span>{selectedRestaurant.location}</span>
                </div>
                <div className="detail-item">
                  <Clock className="w-5 h-5 text-gray-400" />
                  <span>{selectedRestaurant.openHours}</span>
                </div>
                {selectedRestaurant.phone && (
                  <div className="detail-item">
                    <Phone className="w-5 h-5 text-gray-400" />
                    <span>{selectedRestaurant.phone}</span>
                  </div>
                )}
              </div>
              
              <p className="modal-description">{selectedRestaurant.description}</p>
              
              <div className="modal-cost">
                <span className="cost-label">Average Cost:</span>
                <span className="cost-value">{selectedRestaurant.averageCost}</span>
              </div>
              
              {selectedRestaurant.specialties && (
                <div className="modal-specialties">
                  <h4 className="specialties-title">Specialties</h4>
                  <div className="specialties-list">
                    {selectedRestaurant.specialties.map((specialty, index) => (
                      <span key={index} className="specialty-tag">{specialty}</span>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="modal-actions">
                <Button variant="primary" className="action-btn">
                  Make Reservation
                </Button>
                <Button variant="outline" className="action-btn">
                  View Menu
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};