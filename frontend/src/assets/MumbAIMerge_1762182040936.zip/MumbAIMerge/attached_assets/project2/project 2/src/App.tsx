import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import { LandingPage } from './components/landing/LandingPage/LandingPage';
import { RegisterPage } from './components/auth/RegisterPage/RegisterPage';
import { ProfilePage } from './components/profile/ProfilePage/ProfilePage';
import { Header } from './components/layout/Header/Header';
import { HomePage } from './components/pages/HomePage/HomePage';
import { DiningPage } from './components/pages/DiningPage/DiningPage';
import { EventsPage } from './components/pages/EventsPage/EventsPage';
import { MoviesPage } from './components/pages/MoviesPage/MoviesPage';
import { ActivitiesPage } from './components/pages/ActivitiesPage/ActivitiesPage';
import { UserTypeSelection } from './components/auth/UserTypeSelection/UserTypeSelection';
import { TouristProfile } from './components/tourist/TouristProfile/TouristProfile';
import { LocalDashboard } from './components/local/LocalDashboard/LocalDashboard';
import { ItineraryGenerator } from './components/tourist/ItineraryGenerator/ItineraryGenerator';
import { AdminDashboard } from './components/admin/AdminDashboard/AdminDashboard';
import { MoodBasedSearch } from './components/search/MoodBasedSearch/MoodBasedSearch';
import { TouristPreferences, Analytics, Activity } from './types';

type AppState = 'for-you' | 'dining' | 'events' | 'movies' | 'activities' | 'ai-planner';

function App() {
  const { user, isLoading } = useAuth();
  const [currentState, setCurrentState] = useState<AppState>('for-you');
  const [touristPreferences, setTouristPreferences] = useState<TouristPreferences | null>(null);

  // Mock analytics data for admin dashboard
  const mockAnalytics: Analytics = {
    popularSpots: [
      { id: '1', name: 'Gateway of India', visits: 15420, rating: 4.8 },
      { id: '2', name: 'Marine Drive', visits: 12350, rating: 4.7 },
      { id: '3', name: 'Juhu Beach', visits: 9870, rating: 4.5 },
      { id: '4', name: 'Elephanta Caves', visits: 7650, rating: 4.6 }
    ],
    frequentItineraries: [
      { id: '1', title: 'Mumbai Heritage Trail', bookings: 234 },
      { id: '2', title: 'Bollywood & Beaches', bookings: 189 },
      { id: '3', title: 'Street Food Adventure', bookings: 156 }
    ],
    userFeedback: {
      averageRating: 4.7,
      totalReviews: 2847,
      categories: {
        'Historical Sites': 4.8,
        'Street Food': 4.9,
        'Beaches': 4.5,
        'Shopping': 4.3,
        'Nightlife': 4.6
      }
    }
  };

  const handleUserTypeSelect = (type: 'tourist' | 'local') => {
    if (type === 'tourist') {
      setCurrentState('touristProfile');
    } else {
      setCurrentState('localDashboard');
    }
  };

  const handleTouristProfileComplete = (preferences: TouristPreferences) => {
    setTouristPreferences(preferences);
    setCurrentState('itineraryGenerator');
  };

  const handleStartExploring = () => {
    setCurrentState('for-you');
  };

  const handleDistrictClick = (districtId: string) => {
    console.log('District clicked:', districtId);
    // Navigate to district details
  };

  const handleCategoryClick = (category: string) => {
    console.log('Category clicked:', category);
    // Navigate to category listings
  };

  const handleNavigate = (page: string) => {
    setCurrentState(page as AppState);
  };

  // Show loading screen while checking auth
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto border-4 border-gray-200 border-t-orange-500 rounded-full animate-spin mb-4"></div>
          <p className="text-gray-600">Loading MumbAI Trails...</p>
        </div>
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/profile" element={<ProfilePage />} />
      <Route path="/app/*" element={<AppContent />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

// Separate component for the main app content
function AppContent() {
  const { user } = useAuth();
  const [currentState, setCurrentState] = useState<AppState>('for-you');
  const [touristPreferences, setTouristPreferences] = useState<TouristPreferences | null>(null);

  // Mock analytics data for admin dashboard
  const mockAnalytics: Analytics = {
    popularSpots: [
      { id: '1', name: 'Gateway of India', visits: 15420, rating: 4.8 },
      { id: '2', name: 'Marine Drive', visits: 12350, rating: 4.7 },
      { id: '3', name: 'Juhu Beach', visits: 9870, rating: 4.5 },
      { id: '4', name: 'Elephanta Caves', visits: 7650, rating: 4.6 }
    ],
    frequentItineraries: [
      { id: '1', title: 'Mumbai Heritage Trail', bookings: 234 },
      { id: '2', title: 'Bollywood & Beaches', bookings: 189 },
      { id: '3', title: 'Street Food Adventure', bookings: 156 }
    ],
    userFeedback: {
      averageRating: 4.7,
      totalReviews: 2847,
      categories: {
        'Historical Sites': 4.8,
        'Street Food': 4.9,
        'Beaches': 4.5,
        'Shopping': 4.3,
        'Nightlife': 4.6
      }
    }
  };

  const handleUserTypeSelect = (type: 'tourist' | 'local') => {
    if (type === 'tourist') {
      setCurrentState('ai-planner');
    } else {
      // Handle local user flow
    }
  };

  const handleTouristProfileComplete = (preferences: TouristPreferences) => {
    setTouristPreferences(preferences);
    // Generate itinerary directly
  };

  const handleStartExploring = () => {
    setCurrentState('for-you');
  };

  const handleDistrictClick = (districtId: string) => {
    console.log('District clicked:', districtId);
  };

  const handleCategoryClick = (category: string) => {
    console.log('Category clicked:', category);
  };

  const handleNavigate = (page: string) => {
    setCurrentState(page as AppState);
  };

  const renderCurrentState = () => {
    switch (currentState) {
      case 'for-you':
        return <HomePage onDistrictClick={handleDistrictClick} />;
      
      case 'dining':
        return (
          <DiningPage />
        );
      
      case 'events':
        return (
          <EventsPage />
        );
      
      case 'movies':
        return (
          <MoviesPage />
        );
      
      case 'activities':
        return (
          <ActivitiesPage />
        );
      
      case 'ai-planner':
        if (!user) {
          return <UserTypeSelection onUserTypeSelect={handleUserTypeSelect} />;
        }
        
        if (!touristPreferences) {
          return <TouristProfile onProfileComplete={handleTouristProfileComplete} />;
        }
        return <ItineraryGenerator preferences={touristPreferences} onStartExploring={handleStartExploring} />;
      
      default:
        return <HomePage onDistrictClick={handleDistrictClick} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        user={user ? { name: user.name, isLoggedIn: true } : undefined}
        currentPage={currentState}
        onNavigate={handleNavigate}
      />
      {renderCurrentState()}
    </div>
  );
}

export default App;