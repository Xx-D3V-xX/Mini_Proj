import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  interests: string[];
  avatarUrl?: string;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: RegisterData) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

interface RegisterData {
  name: string;
  email: string;
  password: string;
  interests: string[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored token on app load
    const storedToken = localStorage.getItem('mumbai_trails_token');
    const storedUser = localStorage.getItem('mumbai_trails_user');
    
    if (storedToken && storedUser) {
      setToken(storedToken);
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    try {
      // Mock API call - replace with real endpoint
      const response = await mockLogin(email, password);
      
      setToken(response.token);
      setUser(response.user);
      
      localStorage.setItem('mumbai_trails_token', response.token);
      localStorage.setItem('mumbai_trails_user', JSON.stringify(response.user));
    } catch (error) {
      throw new Error('Invalid credentials');
    }
  };

  const register = async (userData: RegisterData) => {
    try {
      // Mock API call - replace with real endpoint
      const response = await mockRegister(userData);
      
      setToken(response.token);
      setUser(response.user);
      
      localStorage.setItem('mumbai_trails_token', response.token);
      localStorage.setItem('mumbai_trails_user', JSON.stringify(response.user));
    } catch (error) {
      throw new Error('Registration failed');
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('mumbai_trails_token');
    localStorage.removeItem('mumbai_trails_user');
  };

  return (
    <AuthContext.Provider value={{ user, token, login, register, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

// Mock API functions - replace with real API calls
const mockLogin = async (email: string, password: string) => {
  await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay
  
  if (email === 'demo@mumbaitrails.com' && password === 'password') {
    return {
      token: 'mock-jwt-token-' + Date.now(),
      user: {
        id: 'u123',
        name: 'Rachel Demo',
        email: 'demo@mumbaitrails.com',
        interests: ['food', 'heritage'],
        avatarUrl: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=100',
        createdAt: '2025-01-01T12:00:00Z'
      }
    };
  }
  throw new Error('Invalid credentials');
};

const mockRegister = async (userData: RegisterData) => {
  await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay
  
  return {
    token: 'mock-jwt-token-' + Date.now(),
    user: {
      id: 'u' + Date.now(),
      name: userData.name,
      email: userData.email,
      interests: userData.interests,
      avatarUrl: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=100',
      createdAt: new Date().toISOString()
    }
  };
};