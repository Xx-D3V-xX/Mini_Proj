import React, { useState, useEffect } from 'react';
import { User, Settings, Calendar, MapPin, Download, Trash2, CreditCard as Edit, Eye, Share2 } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { Button } from '../../common/Button/Button';
import { useAuth } from '../../../contexts/AuthContext';
import { ProtectedRoute } from '../ProtectedRoute/ProtectedRoute';
import './ProfilePage.css';

interface Itinerary {
  id: string;
  title: string;
  createdAt: string;
  days: number;
  poisCount: number;
  summary: string;
  items: any[];
}

interface HistoryItem {
  id: string;
  placeId: string;
  placeName: string;
  visitDate: string;
  bookingId?: string;
  notes?: string;
  rating?: number;
}

export const ProfilePage: React.FC = () => {
  return (
    <ProtectedRoute>
      <ProfilePageContent />
    </ProtectedRoute>
  );
};

const ProfilePageContent: React.FC = () => {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<'itineraries' | 'history' | 'preferences'>('itineraries');
  const [itineraries, setItineraries] = useState<Itinerary[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedItinerary, setExpandedItinerary] = useState<string | null>(null);

  useEffect(() => {
    loadProfileData();
  }, []);

  const loadProfileData = async () => {
    setIsLoading(true);
    try {
      // Mock API calls - replace with real endpoints
      const [itinerariesData, historyData] = await Promise.all([
        mockGetItineraries(),
        mockGetHistory()
      ]);
      
      setItineraries(itinerariesData.itineraries);
      setHistory(historyData.history);
    } catch (error) {
      console.error('Failed to load profile data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteItinerary = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this itinerary?')) {
      setItineraries(prev => prev.filter(item => item.id !== id));
      // In real app: await deleteItinerary(id);
    }
  };

  const handleExportItinerary = (itinerary: Itinerary) => {
    const dataStr = JSON.stringify(itinerary, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${itinerary.title.replace(/\s+/g, '_')}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleClearHistory = async () => {
    if (window.confirm('Are you sure you want to clear all history? This cannot be undone.')) {
      setHistory([]);
      // In real app: await clearHistory();
    }
  };

  const handleDownloadHistory = () => {
    const dataStr = JSON.stringify(history, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'mumbai_trails_history.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  if (!user) return null;

  return (
    <div className="profile-page">
      <div className="profile-container">
        {/* Profile Header */}
        <Card className="profile-header-card">
          <div className="profile-header">
            <div className="profile-avatar-section">
              <div className="profile-avatar">
                {user.avatarUrl ? (
                  <img src={user.avatarUrl} alt={user.name} className="avatar-image" />
                ) : (
                  <User className="w-12 h-12 text-gray-400" />
                )}
              </div>
              <div className="profile-info">
                <h1 className="profile-name">{user.name}</h1>
                <p className="profile-email">{user.email}</p>
                <div className="profile-interests">
                  {user.interests.map((interest, index) => (
                    <span key={index} className="interest-badge">
                      {interest}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <div className="profile-actions">
              <Button variant="outline" size="sm">
                <Edit className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
              <Button variant="outline" size="sm" onClick={logout}>
                Logout
              </Button>
            </div>
          </div>
        </Card>

        {/* Navigation Tabs */}
        <div className="profile-tabs">
          <button
            className={`tab-button ${activeTab === 'itineraries' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('itineraries')}
          >
            <Calendar className="w-5 h-5" />
            My Itineraries
          </button>
          <button
            className={`tab-button ${activeTab === 'history' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('history')}
          >
            <MapPin className="w-5 h-5" />
            Places Visited
          </button>
          <button
            className={`tab-button ${activeTab === 'preferences' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('preferences')}
          >
            <Settings className="w-5 h-5" />
            Preferences
          </button>
        </div>

        {/* Tab Content */}
        <div className="tab-content">
          {activeTab === 'itineraries' && (
            <div className="itineraries-section">
              <div className="section-header">
                <h2 className="section-title">My Itineraries</h2>
                <p className="section-subtitle">
                  {itineraries.length} saved itineraries
                </p>
              </div>

              {isLoading ? (
                <div className="loading-skeleton">
                  {[1, 2, 3].map(i => (
                    <Card key={i} className="skeleton-card">
                      <div className="skeleton-content">
                        <div className="skeleton-line skeleton-title"></div>
                        <div className="skeleton-line skeleton-text"></div>
                        <div className="skeleton-line skeleton-text short"></div>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : itineraries.length === 0 ? (
                <Card className="empty-state">
                  <div className="empty-content">
                    <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="empty-title">No itineraries yet</h3>
                    <p className="empty-description">
                      You don't have any saved itineraries yet — explore Mumbai and save your first trip!
                    </p>
                    <Button variant="primary" className="mt-4">
                      Create Itinerary
                    </Button>
                  </div>
                </Card>
              ) : (
                <div className="itineraries-list">
                  {itineraries.map((itinerary) => (
                    <Card key={itinerary.id} className="itinerary-card">
                      <div className="itinerary-header">
                        <div className="itinerary-info">
                          <h3 className="itinerary-title">{itinerary.title}</h3>
                          <div className="itinerary-meta">
                            <span className="meta-item">
                              Created {new Date(itinerary.createdAt).toLocaleDateString()}
                            </span>
                            <span className="meta-item">
                              {itinerary.days} days • {itinerary.poisCount} places
                            </span>
                          </div>
                          <p className="itinerary-summary">{itinerary.summary}</p>
                        </div>
                        <div className="itinerary-actions">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setExpandedItinerary(
                              expandedItinerary === itinerary.id ? null : itinerary.id
                            )}
                          >
                            <Eye className="w-4 h-4 mr-1" />
                            {expandedItinerary === itinerary.id ? 'Hide' : 'View'}
                          </Button>
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4 mr-1" />
                            Edit
                          </Button>
                          <Button variant="outline" size="sm">
                            <Share2 className="w-4 h-4 mr-1" />
                            Share
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleExportItinerary(itinerary)}
                          >
                            <Download className="w-4 h-4 mr-1" />
                            Export
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeleteItinerary(itinerary.id)}
                            className="delete-button"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>

                      {expandedItinerary === itinerary.id && (
                        <div className="itinerary-details">
                          <h4 className="details-title">Itinerary Details</h4>
                          <div className="details-content">
                            {itinerary.items.map((item, index) => (
                              <div key={index} className="detail-item">
                                <div className="detail-time">Day {item.day}</div>
                                <div className="detail-info">
                                  <h5 className="detail-place">{item.place}</h5>
                                  <p className="detail-description">{item.description}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'history' && (
            <div className="history-section">
              <div className="section-header">
                <h2 className="section-title">Places Visited</h2>
                <div className="section-actions">
                  <Button variant="outline" size="sm" onClick={handleDownloadHistory}>
                    <Download className="w-4 h-4 mr-2" />
                    Download History
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleClearHistory}
                    className="delete-button"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear History
                  </Button>
                </div>
              </div>

              {history.length === 0 ? (
                <Card className="empty-state">
                  <div className="empty-content">
                    <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="empty-title">No places visited yet</h3>
                    <p className="empty-description">
                      Start exploring Mumbai and your visit history will appear here!
                    </p>
                  </div>
                </Card>
              ) : (
                <div className="history-list">
                  {history.map((item) => (
                    <Card key={item.id} className="history-card">
                      <div className="history-content">
                        <div className="history-info">
                          <h3 className="history-place">{item.placeName}</h3>
                          <div className="history-meta">
                            <span className="history-date">
                              Visited {new Date(item.visitDate).toLocaleDateString()}
                            </span>
                            {item.bookingId && (
                              <span className="history-booking">
                                Booking: {item.bookingId}
                              </span>
                            )}
                          </div>
                          {item.notes && (
                            <p className="history-notes">{item.notes}</p>
                          )}
                        </div>
                        {item.rating && (
                          <div className="history-rating">
                            <div className="rating-stars">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <span
                                  key={star}
                                  className={`star ${star <= item.rating! ? 'star-filled' : ''}`}
                                >
                                  ★
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'preferences' && (
            <div className="preferences-section">
              <div className="section-header">
                <h2 className="section-title">Travel Preferences</h2>
                <p className="section-subtitle">
                  Customize your Mumbai experience
                </p>
              </div>

              <div className="preferences-grid">
                <Card className="preference-card">
                  <h3 className="preference-title">Interests</h3>
                  <div className="interests-list">
                    {user.interests.map((interest, index) => (
                      <span key={index} className="interest-tag">
                        {interest}
                      </span>
                    ))}
                  </div>
                  <Button variant="outline" size="sm" className="mt-4">
                    Edit Interests
                  </Button>
                </Card>

                <Card className="preference-card">
                  <h3 className="preference-title">Budget Range</h3>
                  <div className="budget-slider">
                    <input
                      type="range"
                      min="1000"
                      max="10000"
                      defaultValue="5000"
                      className="slider"
                    />
                    <div className="budget-labels">
                      <span>₹1,000</span>
                      <span>₹10,000</span>
                    </div>
                  </div>
                </Card>

                <Card className="preference-card">
                  <h3 className="preference-title">Travel Mode</h3>
                  <div className="travel-modes">
                    {['Walking', 'Public Transport', 'Taxi', 'Auto Rickshaw'].map((mode) => (
                      <label key={mode} className="mode-option">
                        <input type="checkbox" defaultChecked />
                        <span>{mode}</span>
                      </label>
                    ))}
                  </div>
                </Card>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Mock API functions
const mockGetItineraries = async () => {
  await new Promise(resolve => setTimeout(resolve, 1000));
  return {
    itineraries: [
      {
        id: 'it1',
        title: '1-Day Food & Sunset: Colaba to Marine Drive',
        createdAt: '2024-12-10T10:00:00Z',
        days: 1,
        poisCount: 5,
        summary: 'Food + Marine Drive sunset experience',
        items: [
          { day: 1, place: 'Leopold Cafe', description: 'Breakfast & coffee' },
          { day: 1, place: 'Crawford Market', description: 'Local shopping experience' },
          { day: 1, place: 'Mohammed Ali Road', description: 'Street food tour' },
          { day: 1, place: 'Gateway of India', description: 'Historic landmark' },
          { day: 1, place: 'Marine Drive', description: 'Sunset viewing' }
        ]
      },
      {
        id: 'it2',
        title: '3-Day Heritage & Culture Mumbai Tour',
        createdAt: '2024-12-08T14:30:00Z',
        days: 3,
        poisCount: 12,
        summary: 'Complete heritage and cultural exploration',
        items: [
          { day: 1, place: 'Chhatrapati Shivaji Terminus', description: 'Victorian architecture' },
          { day: 2, place: 'Elephanta Caves', description: 'Ancient rock-cut temples' },
          { day: 3, place: 'Bollywood Studio Tour', description: 'Film industry insights' }
        ]
      },
      {
        id: 'it3',
        title: '2-Day Beach & Adventure Mumbai',
        createdAt: '2024-12-05T09:15:00Z',
        days: 2,
        poisCount: 8,
        summary: 'Beaches, water sports, and adventure activities',
        items: [
          { day: 1, place: 'Juhu Beach', description: 'Beach activities and street food' },
          { day: 2, place: 'Versova Beach', description: 'Water sports and sunset' }
        ]
      }
    ],
    meta: { page: 1, limit: 10, total: 3 }
  };
};

const mockGetHistory = async () => {
  await new Promise(resolve => setTimeout(resolve, 800));
  return {
    history: [
      {
        id: 'h1',
        placeId: 'p1',
        placeName: 'Gateway of India',
        visitDate: '2024-12-10T16:00:00Z',
        bookingId: 'BK001',
        notes: 'Amazing sunset views, very crowded but worth it',
        rating: 5
      },
      {
        id: 'h2',
        placeId: 'p2',
        placeName: 'Leopold Cafe',
        visitDate: '2024-12-10T09:30:00Z',
        notes: 'Great breakfast, historic ambiance',
        rating: 4
      },
      {
        id: 'h3',
        placeId: 'p3',
        placeName: 'Marine Drive',
        visitDate: '2024-12-10T18:00:00Z',
        notes: 'Perfect for evening walks, beautiful sea view',
        rating: 5
      },
      {
        id: 'h4',
        placeId: 'p4',
        placeName: 'Elephanta Caves',
        visitDate: '2024-12-08T11:00:00Z',
        bookingId: 'BK002',
        notes: 'Incredible ancient sculptures, ferry ride was fun',
        rating: 4
      },
      {
        id: 'h5',
        placeId: 'p5',
        placeName: 'Crawford Market',
        visitDate: '2024-12-08T14:00:00Z',
        notes: 'Vibrant local market, great for shopping',
        rating: 4
      },
      {
        id: 'h6',
        placeId: 'p6',
        placeName: 'Juhu Beach',
        visitDate: '2024-12-05T17:30:00Z',
        notes: 'Enjoyed street food and beach activities',
        rating: 4
      }
    ],
    meta: { page: 1, limit: 10, total: 6 }
  };
};