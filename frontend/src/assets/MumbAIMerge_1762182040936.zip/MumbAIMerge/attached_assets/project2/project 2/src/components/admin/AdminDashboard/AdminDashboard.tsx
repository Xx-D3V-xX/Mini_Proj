import React, { useState } from 'react';
import { BarChart3, Users, MapPin, TrendingUp, Calendar, Star, Download, Eye } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { Button } from '../../common/Button/Button';
import { Analytics } from '../../../types';
import './AdminDashboard.css';

interface AdminDashboardProps {
  analytics: Analytics;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ analytics }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'spots' | 'itineraries' | 'feedback'>('overview');

  const stats = [
    { label: 'Total Users', value: '12,543', icon: Users, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Active Itineraries', value: '3,247', icon: MapPin, color: 'text-green-600', bg: 'bg-green-100' },
    { label: 'Popular Spots', value: '156', icon: TrendingUp, color: 'text-orange-600', bg: 'bg-orange-100' },
    { label: 'Avg Rating', value: '4.7', icon: Star, color: 'text-yellow-600', bg: 'bg-yellow-100' }
  ];

  return (
    <div className="admin-dashboard">
      <div className="admin-container">
        <div className="admin-header">
          <h1 className="admin-title">Admin Dashboard</h1>
          <p className="admin-subtitle">Mumbai Tourism Analytics & Management</p>
        </div>

        {/* Stats Overview */}
        <div className="stats-grid">
          {stats.map((stat, index) => (
            <Card key={index} className="stat-card">
              <div className="stat-content">
                <div className={`stat-icon ${stat.bg}`}>
                  <stat.icon className={`w-8 h-8 ${stat.color}`} />
                </div>
                <div className="stat-info">
                  <div className="stat-value">{stat.value}</div>
                  <div className="stat-label">{stat.label}</div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Navigation Tabs */}
        <div className="admin-tabs">
          {[
            { id: 'overview', label: 'Overview', icon: BarChart3 },
            { id: 'spots', label: 'Popular Spots', icon: MapPin },
            { id: 'itineraries', label: 'Itineraries', icon: Calendar },
            { id: 'feedback', label: 'User Feedback', icon: Star }
          ].map(tab => (
            <button
              key={tab.id}
              className={`tab-button ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id as any)}
            >
              <tab.icon className="w-5 h-5" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="tab-content">
          {activeTab === 'overview' && (
            <div className="overview-content">
              <div className="overview-grid">
                <Card className="chart-card">
                  <h3 className="chart-title">Monthly Visitors</h3>
                  <div className="chart-placeholder">
                    <BarChart3 className="w-16 h-16 text-gray-400" />
                    <p className="text-gray-500">Chart visualization would go here</p>
                  </div>
                </Card>
                
                <Card className="chart-card">
                  <h3 className="chart-title">Popular Districts</h3>
                  <div className="district-stats">
                    {['South Mumbai', 'Bandra', 'Juhu', 'Andheri'].map((district, index) => (
                      <div key={district} className="district-stat">
                        <span className="district-name">{district}</span>
                        <div className="district-bar">
                          <div 
                            className="district-fill"
                            style={{ width: `${90 - index * 15}%` }}
                          />
                        </div>
                        <span className="district-percentage">{90 - index * 15}%</span>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>
            </div>
          )}

          {activeTab === 'spots' && (
            <div className="spots-content">
              <div className="spots-header">
                <h3 className="section-title">Most Popular Attractions</h3>
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Export Data
                </Button>
              </div>
              
              <div className="spots-grid">
                {analytics.popularSpots.map((spot, index) => (
                  <Card key={spot.id} className="spot-card">
                    <div className="spot-rank">#{index + 1}</div>
                    <div className="spot-info">
                      <h4 className="spot-name">{spot.name}</h4>
                      <div className="spot-stats">
                        <div className="spot-stat">
                          <Eye className="w-4 h-4 text-gray-400" />
                          <span>{spot.visits.toLocaleString()} visits</span>
                        </div>
                        <div className="spot-stat">
                          <Star className="w-4 h-4 text-yellow-500" />
                          <span>{spot.rating}</span>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'itineraries' && (
            <div className="itineraries-content">
              <div className="itineraries-header">
                <h3 className="section-title">Most Booked Itineraries</h3>
                <Button variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Export Data
                </Button>
              </div>
              
              <div className="itineraries-list">
                {analytics.frequentItineraries.map((itinerary, index) => (
                  <Card key={itinerary.id} className="itinerary-card">
                    <div className="itinerary-rank">#{index + 1}</div>
                    <div className="itinerary-info">
                      <h4 className="itinerary-title">{itinerary.title}</h4>
                      <div className="itinerary-bookings">
                        {itinerary.bookings} bookings this month
                      </div>
                    </div>
                    <Button variant="outline" size="sm">View Details</Button>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'feedback' && (
            <div className="feedback-content">
              <div className="feedback-overview">
                <Card className="feedback-summary">
                  <h3 className="section-title">User Feedback Summary</h3>
                  <div className="feedback-stats">
                    <div className="feedback-stat">
                      <div className="feedback-value">{analytics.userFeedback.averageRating}</div>
                      <div className="feedback-label">Average Rating</div>
                    </div>
                    <div className="feedback-stat">
                      <div className="feedback-value">{analytics.userFeedback.totalReviews.toLocaleString()}</div>
                      <div className="feedback-label">Total Reviews</div>
                    </div>
                  </div>
                </Card>
              </div>
              
              <Card className="category-feedback">
                <h4 className="section-title">Feedback by Category</h4>
                <div className="category-stats">
                  {Object.entries(analytics.userFeedback.categories).map(([category, rating]) => (
                    <div key={category} className="category-stat">
                      <span className="category-name">{category}</span>
                      <div className="category-rating">
                        <Star className="w-4 h-4 text-yellow-500 fill-current" />
                        <span>{rating}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};