import React, { useState } from 'react';
import { Search, MapPin, Clock, Filter, Zap } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { Button } from '../../common/Button/Button';
import { Activity, Location } from '../../../types';
import './MoodBasedSearch.css';

interface SearchFilters {
  mood: string;
  location: string;
  timeAvailable: string;
  budget: string;
}

interface MoodBasedSearchProps {
  onSearchResults: (results: Activity[]) => void;
}

export const MoodBasedSearch: React.FC<MoodBasedSearchProps> = ({ onSearchResults }) => {
  const [filters, setFilters] = useState<SearchFilters>({
    mood: '',
    location: '',
    timeAvailable: '',
    budget: ''
  });
  const [isSearching, setIsSearching] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  const moods = [
    { id: 'relaxed', label: 'Relaxed', icon: '🧘', color: 'bg-green-100 text-green-700' },
    { id: 'adventurous', label: 'Adventurous', icon: '🏔️', color: 'bg-red-100 text-red-700' },
    { id: 'foodie', label: 'Foodie', icon: '🍽️', color: 'bg-orange-100 text-orange-700' },
    { id: 'heritage', label: 'Heritage', icon: '🏛️', color: 'bg-purple-100 text-purple-700' },
    { id: 'cultural', label: 'Cultural', icon: '🎭', color: 'bg-blue-100 text-blue-700' },
    { id: 'nightlife', label: 'Nightlife', icon: '🌃', color: 'bg-indigo-100 text-indigo-700' }
  ];

  const locations = [
    'South Mumbai', 'Bandra', 'Juhu', 'Andheri', 'Lower Parel', 
    'Worli', 'Powai', 'Thane', 'Navi Mumbai', 'Anywhere'
  ];

  const timeSlots = [
    '1-2 hours', '2-4 hours', '4-6 hours', 'Half day', 'Full day'
  ];

  const budgetRanges = [
    'Under ₹500', '₹500-₹1000', '₹1000-₹2500', '₹2500-₹5000', 'Above ₹5000'
  ];

  const handleSearch = async () => {
    setIsSearching(true);
    
    // Simulate API call with mood-based search
    setTimeout(() => {
      const mockResults: Activity[] = [
        {
          id: '1',
          name: 'Marine Drive Sunset Walk',
          category: 'activities',
          district: 'South Mumbai',
          rating: 4.8,
          price: 'Free',
          coordinates: { lat: 18.9434, lng: 72.8234 },
          mood: ['relaxed', 'heritage'],
          duration: 2,
          description: 'Peaceful evening walk along the iconic Marine Drive',
          images: ['https://images.pexels.com/photos/3741169/pexels-photo-3741169.jpeg'],
          openingHours: { 'all': '24 hours' }
        },
        {
          id: '2',
          name: 'Street Food Tour at Mohammed Ali Road',
          category: 'dining',
          district: 'South Mumbai',
          rating: 4.6,
          price: '₹300-₹500',
          coordinates: { lat: 18.9667, lng: 72.8333 },
          mood: ['foodie', 'adventurous'],
          duration: 3,
          description: 'Authentic Mumbai street food experience',
          images: ['https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg'],
          openingHours: { 'all': '6 PM - 2 AM' }
        }
      ];
      
      // Filter results based on selected mood
      const filteredResults = filters.mood 
        ? mockResults.filter(activity => activity.mood.includes(filters.mood))
        : mockResults;
      
      onSearchResults(filteredResults);
      setIsSearching(false);
    }, 1500);
  };

  return (
    <div className="mood-search">
      <Card className="search-card">
        <div className="search-header">
          <div className="search-title-section">
            <Zap className="w-8 h-8 text-orange-500" />
            <div>
              <h2 className="search-title">Find by Mood</h2>
              <p className="search-subtitle">Discover experiences that match your vibe</p>
            </div>
          </div>
          
          <Button 
            variant="outline" 
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="w-4 h-4 mr-2" />
            Filters
          </Button>
        </div>

        {/* Mood Selection */}
        <div className="mood-section">
          <h3 className="section-title">What's your mood?</h3>
          <div className="mood-grid">
            {moods.map(mood => (
              <button
                key={mood.id}
                className={`mood-chip ${filters.mood === mood.id ? 'selected' : ''} ${mood.color}`}
                onClick={() => setFilters({ ...filters, mood: mood.id })}
              >
                <span className="mood-icon">{mood.icon}</span>
                <span className="mood-label">{mood.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Advanced Filters */}
        {showFilters && (
          <div className="filters-section">
            <div className="filters-grid">
              <div className="filter-group">
                <label className="filter-label">
                  <MapPin className="w-4 h-4" />
                  Location
                </label>
                <select 
                  className="filter-select"
                  value={filters.location}
                  onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                >
                  <option value="">Any location</option>
                  {locations.map(location => (
                    <option key={location} value={location}>{location}</option>
                  ))}
                </select>
              </div>

              <div className="filter-group">
                <label className="filter-label">
                  <Clock className="w-4 h-4" />
                  Time Available
                </label>
                <select 
                  className="filter-select"
                  value={filters.timeAvailable}
                  onChange={(e) => setFilters({ ...filters, timeAvailable: e.target.value })}
                >
                  <option value="">Any duration</option>
                  {timeSlots.map(slot => (
                    <option key={slot} value={slot}>{slot}</option>
                  ))}
                </select>
              </div>

              <div className="filter-group">
                <label className="filter-label">Budget Range</label>
                <select 
                  className="filter-select"
                  value={filters.budget}
                  onChange={(e) => setFilters({ ...filters, budget: e.target.value })}
                >
                  <option value="">Any budget</option>
                  {budgetRanges.map(range => (
                    <option key={range} value={range}>{range}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Search Button */}
        <div className="search-actions">
          <Button 
            variant="primary" 
            size="lg" 
            onClick={handleSearch}
            disabled={isSearching || !filters.mood}
            className="search-button"
          >
            <Search className="w-5 h-5 mr-2" />
            {isSearching ? 'Searching...' : 'Find Experiences'}
          </Button>
        </div>
      </Card>
    </div>
  );
};