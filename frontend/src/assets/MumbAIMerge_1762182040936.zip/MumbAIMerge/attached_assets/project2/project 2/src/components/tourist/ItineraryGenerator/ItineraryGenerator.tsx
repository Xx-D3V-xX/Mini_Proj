import React, { useState, useEffect } from 'react';
import { Clock, MapPin, Star, Users, Save, Share2, Download, Copy, QrCode } from 'lucide-react';
import { Card } from '../../common/Card/Card';
import { Button } from '../../common/Button/Button';
import { TouristPreferences } from '../../../types';
import './ItineraryGenerator.css';

interface ItineraryGeneratorProps {
  preferences: TouristPreferences;
  onStartExploring: () => void;
}

export const ItineraryGenerator: React.FC<ItineraryGeneratorProps> = ({ 
  preferences, 
  onStartExploring 
}) => {
  const [isGenerating, setIsGenerating] = useState(true);
  const [itinerary, setItinerary] = useState<any[]>([]);
  const [isSaved, setIsSaved] = useState(false);
  const [shareLink, setShareLink] = useState('');
  const [showShareModal, setShowShareModal] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    // Simulate itinerary generation
    setTimeout(() => {
      const mockItinerary = generateMockItinerary(preferences);
      setItinerary(mockItinerary);
      setIsGenerating(false);
    }, 2000);
  }, [preferences]);

  const generateMockItinerary = (prefs: TouristPreferences) => {
    const days = [];
    
    // Generate activities based on user's mood and preferences
    const moodBasedActivities = getMoodBasedActivities(prefs.mood);
    const categoryActivities = getCategoryBasedActivities(prefs.preferredCategories || []);
    const budgetActivities = getBudgetBasedActivities(prefs.budget);
    
    for (let i = 1; i <= prefs.duration; i++) {
      days.push({
        day: i,
        title: `Day ${i} - ${getDayTitle(i, prefs.mood)}`,
        activities: getDayActivities(i, prefs, moodBasedActivities, categoryActivities, budgetActivities)
      });
    }
    return days;
  };

  const getMoodBasedActivities = (mood: string) => {
    const moodActivities: { [key: string]: any[] } = {
      'relaxed': [
        { name: 'Marine Drive Sunset Walk', type: 'Scenic', duration: '2 hours', cost: 'Free' },
        { name: 'Hanging Gardens', type: 'Nature', duration: '1.5 hours', cost: 'Free' },
        { name: 'Juhu Beach', type: 'Beach', duration: '2 hours', cost: 'Free' }
      ],
      'adventurous': [
        { name: 'Elephanta Caves Trek', type: 'Adventure', duration: '4 hours', cost: '₹500' },
        { name: 'Bungee Jumping at Lonavala', type: 'Adventure', duration: '3 hours', cost: '₹2500' },
        { name: 'Parasailing at Juhu', type: 'Water Sports', duration: '1 hour', cost: '₹1500' }
      ],
      'foodie': [
        { name: 'Mohammed Ali Road Food Tour', type: 'Food Tour', duration: '3 hours', cost: '₹800' },
        { name: 'Khau Galli Street Food', type: 'Street Food', duration: '2 hours', cost: '₹400' },
        { name: 'Cooking Class in Bandra', type: 'Workshop', duration: '4 hours', cost: '₹2000' }
      ],
      'heritage': [
        { name: 'Gateway of India', type: 'Monument', duration: '1 hour', cost: 'Free' },
        { name: 'Chhatrapati Shivaji Terminus', type: 'Architecture', duration: '1 hour', cost: 'Free' },
        { name: 'Mani Bhavan Gandhi Museum', type: 'Museum', duration: '2 hours', cost: '₹100' }
      ],
      'cultural': [
        { name: 'Bollywood Studio Tour', type: 'Entertainment', duration: '4 hours', cost: '₹1200' },
        { name: 'Kala Ghoda Art District', type: 'Art', duration: '3 hours', cost: 'Free' },
        { name: 'Traditional Dance Show', type: 'Performance', duration: '2 hours', cost: '₹800' }
      ],
      'nightlife': [
        { name: 'Rooftop Bar in Lower Parel', type: 'Nightlife', duration: '3 hours', cost: '₹2000' },
        { name: 'Marine Drive Night Walk', type: 'Scenic', duration: '2 hours', cost: 'Free' },
        { name: 'Club Hopping in Bandra', type: 'Nightlife', duration: '4 hours', cost: '₹3000' }
      ]
    };
    return moodActivities[mood] || moodActivities['heritage'];
  };

  const getCategoryBasedActivities = (categories: string[]) => {
    const categoryMap: { [key: string]: any[] } = {
      'Historical Sites': [
        { name: 'Crawford Market', type: 'Historical', duration: '2 hours', cost: 'Free' },
        { name: 'Asiatic Library', type: 'Historical', duration: '1 hour', cost: '₹50' }
      ],
      'Street Food': [
        { name: 'Vada Pav at Ashok Vada Pav', type: 'Street Food', duration: '30 min', cost: '₹100' },
        { name: 'Pav Bhaji at Sardar', type: 'Street Food', duration: '45 min', cost: '₹200' }
      ],
      'Beaches': [
        { name: 'Versova Beach', type: 'Beach', duration: '2 hours', cost: 'Free' },
        { name: 'Aksa Beach', type: 'Beach', duration: '3 hours', cost: 'Free' }
      ],
      'Shopping': [
        { name: 'Linking Road Shopping', type: 'Shopping', duration: '3 hours', cost: '₹1000+' },
        { name: 'Palladium Mall', type: 'Shopping', duration: '2 hours', cost: '₹500+' }
      ]
    };
    
    let activities: any[] = [];
    categories.forEach(category => {
      if (categoryMap[category]) {
        activities = activities.concat(categoryMap[category]);
      }
    });
    return activities;
  };

  const getBudgetBasedActivities = (budget: string) => {
    const budgetMap: { [key: string]: any[] } = {
      'budget': [
        { name: 'Local Train Experience', type: 'Transport', duration: '1 hour', cost: '₹50' },
        { name: 'Street Photography Walk', type: 'Photography', duration: '2 hours', cost: 'Free' }
      ],
      'moderate': [
        { name: 'Taxi Tour of Mumbai', type: 'Sightseeing', duration: '4 hours', cost: '₹1500' },
        { name: 'Lunch at Popular Restaurant', type: 'Dining', duration: '1.5 hours', cost: '₹800' }
      ],
      'luxury': [
        { name: 'Helicopter Tour of Mumbai', type: 'Luxury', duration: '1 hour', cost: '₹15000' },
        { name: 'Fine Dining at Taj Hotel', type: 'Luxury Dining', duration: '2 hours', cost: '₹5000' }
      ]
    };
    return budgetMap[budget] || budgetMap['moderate'];
  };

  const getDayTitle = (day: number, mood: string) => {
    const moodTitles: { [key: string]: string[] } = {
      'relaxed': ['Peaceful Mumbai', 'Serene Spots', 'Calm Exploration', 'Tranquil Day', 'Relaxing Mumbai'],
      'adventurous': ['Thrilling Mumbai', 'Adventure Day', 'Exciting Exploration', 'Adrenaline Rush', 'Bold Mumbai'],
      'foodie': ['Culinary Mumbai', 'Food Paradise', 'Taste Adventure', 'Flavor Journey', 'Foodie Heaven'],
      'heritage': ['Historic Mumbai', 'Cultural Heritage', 'Legacy Tour', 'Heritage Walk', 'Historic Gems'],
      'cultural': ['Cultural Mumbai', 'Art & Culture', 'Creative Mumbai', 'Cultural Immersion', 'Artistic Journey'],
      'nightlife': ['Mumbai After Dark', 'Night Adventures', 'Evening Delights', 'Nightlife Tour', 'Mumbai Nights']
    };
    
    const titles = moodTitles[mood] || moodTitles['heritage'];
    return titles[(day - 1) % titles.length];
  };

  const getDayActivities = (day: number, prefs: TouristPreferences, moodActivities: any[], categoryActivities: any[], budgetActivities: any[]) => {
    // Combine all activity pools
    const allActivities = [...moodActivities, ...categoryActivities, ...budgetActivities];
    
    // Select activities based on available time and preferences
    const timeSlots = prefs.availableTime === 'morning' ? ['9:00 AM', '11:00 AM'] :
                     prefs.availableTime === 'afternoon' ? ['1:00 PM', '3:00 PM', '5:00 PM'] :
                     prefs.availableTime === 'evening' ? ['6:00 PM', '8:00 PM'] :
                     ['9:00 AM', '11:00 AM', '1:00 PM', '3:00 PM', '6:00 PM'];
    
    const selectedActivities = [];
    const usedActivities = new Set();
    
    for (let i = 0; i < Math.min(timeSlots.length, allActivities.length); i++) {
      let activity = allActivities[i % allActivities.length];
      let attempts = 0;
      
      // Avoid duplicate activities
      while (usedActivities.has(activity.name) && attempts < allActivities.length) {
        activity = allActivities[(i + attempts) % allActivities.length];
        attempts++;
      }
      
      if (!usedActivities.has(activity.name)) {
        selectedActivities.push({
          time: timeSlots[i],
          name: activity.name,
          type: activity.type,
          duration: activity.duration,
          cost: activity.cost
        });
        usedActivities.add(activity.name);
      }
    }
    
    return selectedActivities;
  };

  const handleSaveItinerary = () => {
    // Simulate saving to backend
    setIsSaved(true);
    // In real implementation, this would save to database
    console.log('Itinerary saved:', { preferences, itinerary });
  };

  const handleShareItinerary = () => {
    // Generate shareable link
    const itineraryId = Math.random().toString(36).substr(2, 9);
    const link = `https://mumbaitrails.com/shared/${itineraryId}`;
    setShareLink(link);
    setShowShareModal(true);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareLink);
    // Show toast notification in real implementation
    alert('Link copied to clipboard!');
  };

  const handleExportPDF = () => {
    setIsExporting(true);
    // Simulate PDF generation
    setTimeout(() => {
      // In real implementation, this would generate and download PDF
      const element = document.createElement('a');
      element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent('Mumbai Itinerary PDF'));
      element.setAttribute('download', 'mumbai-itinerary.pdf');
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
      setIsExporting(false);
    }, 2000);
  };

  const generateQRCode = () => {
    return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(shareLink)}`;
  };

  if (isGenerating) {
    return (
      <div className="itinerary-loading">
        <div className="loading-container">
          <div className="loading-spinner"></div>
          <h3 className="loading-title">Creating your perfect Mumbai itinerary...</h3>
          <p className="loading-subtitle">
            Analyzing {preferences.interests?.length} interests for {preferences.duration} days
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="itinerary-section">
      <div className="itinerary-container">
        <div className="itinerary-header">
          <h2 className="itinerary-title">Your Mumbai Adventure</h2>
          <div className="itinerary-summary">
            <div className="summary-item">
              <Clock className="w-5 h-5" />
              <span>{preferences.duration} Days</span>
            </div>
            <div className="summary-item">
              <Users className="w-5 h-5" />
              <span>{preferences.groupSize} {preferences.groupSize === 1 ? 'Person' : 'People'}</span>
            </div>
            <div className="summary-item">
              <Star className="w-5 h-5" />
              <span>{preferences.budget} Budget</span>
            </div>
          </div>
        </div>
        
        <div className="itinerary-timeline">
          {itinerary.map((day, index) => (
            <Card key={day.day} className="day-card">
              <div className="day-header">
                <div className="day-number">{day.day}</div>
                <h3 className="day-title">{day.title}</h3>
              </div>
              
              <div className="day-activities">
                {day.activities.map((activity: any, actIndex: number) => (
                  <div key={actIndex} className="activity-item">
                    <div className="activity-time">{activity.time}</div>
                    <div className="activity-details">
                      <h4 className="activity-name">{activity.name}</h4>
                      <div className="activity-meta">
                        <span className="activity-type">{activity.type}</span>
                        <span className="activity-duration">{activity.duration}</span>
                        <span className="activity-cost">{activity.cost}</span>
                      </div>
                    </div>
                    <MapPin className="w-4 h-4 text-gray-400" />
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
        
        <div className="itinerary-actions">
          <div className="action-buttons">
            <Button 
              variant="outline" 
              onClick={handleSaveItinerary}
              disabled={isSaved}
            >
              <Save className="w-4 h-4 mr-2" />
              {isSaved ? 'Saved' : 'Save Itinerary'}
            </Button>
            
            <Button 
              variant="outline" 
              onClick={handleShareItinerary}
            >
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
            
            <Button 
              variant="outline" 
              onClick={handleExportPDF}
              disabled={isExporting}
            >
              <Download className="w-4 h-4 mr-2" />
              {isExporting ? 'Generating...' : 'Export PDF'}
            </Button>
          </div>
          
          <Button variant="primary" size="lg" onClick={onStartExploring}>
            Start Exploring Mumbai
          </Button>
        </div>
        
        {/* Share Modal */}
        {showShareModal && (
          <div className="share-modal-overlay" onClick={() => setShowShareModal(false)}>
            <Card className="share-modal" onClick={(e) => e.stopPropagation()}>
              <div className="share-modal-header">
                <h3 className="share-modal-title">Share Your Itinerary</h3>
                <button 
                  className="share-modal-close"
                  onClick={() => setShowShareModal(false)}
                >
                  ×
                </button>
              </div>
              
              <div className="share-modal-content">
                <div className="share-options">
                  <div className="share-link-section">
                    <label className="share-label">Shareable Link</label>
                    <div className="share-link-container">
                      <input 
                        type="text" 
                        value={shareLink} 
                        readOnly 
                        className="share-link-input"
                      />
                      <Button variant="outline" size="sm" onClick={handleCopyLink}>
                        <Copy className="w-4 h-4 mr-1" />
                        Copy
                      </Button>
                    </div>
                  </div>
                  
                  <div className="share-qr-section">
                    <label className="share-label">QR Code</label>
                    <div className="qr-code-container">
                      <img 
                        src={generateQRCode()} 
                        alt="QR Code" 
                        className="qr-code-image"
                      />
                      <p className="qr-code-description">
                        Scan to view itinerary on mobile
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};