import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Zap, Cloud, Save, Search, Clock, Star } from 'lucide-react';
import { Button } from '../../common/Button/Button';
import { Card } from '../../common/Card/Card';
import { AuthModal } from '../AuthModal/AuthModal';
import './LandingPage.css';

export const LandingPage: React.FC = () => {
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const features = [
    {
      icon: Zap,
      title: 'AI Recommendations',
      description: 'Get personalized itineraries based on your mood, budget, and interests'
    },
    {
      icon: Cloud,
      title: 'Real-time Weather & Maps',
      description: 'Live weather updates and optimized routes for your Mumbai adventure'
    },
    {
      icon: Save,
      title: 'Save & Revisit Itineraries',
      description: 'Save your favorite trips and share them with friends via QR codes'
    }
  ];

  const searchSuggestions = [
    'Street food tours',
    'Heritage walks',
    'Beach activities',
    'Bollywood experiences',
    'Night markets',
    'Art galleries'
  ];

  const sampleItinerary = {
    title: '1-Day Food & Sunset: Colaba to Marine Drive',
    activities: [
      { time: '9:00 AM', place: 'Leopold Cafe', note: 'Breakfast & coffee' },
      { time: '11:00 AM', place: 'Crawford Market', note: 'Local shopping experience' },
      { time: '1:00 PM', place: 'Mohammed Ali Road', note: 'Street food tour' },
      { time: '4:00 PM', place: 'Gateway of India', note: 'Historic landmark' },
      { time: '6:00 PM', place: 'Marine Drive', note: 'Sunset viewing' }
    ]
  };

  return (
    <div className="landing-page">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-container">
          <div className="hero-content">
            <div className="hero-badge">
              <MapPin className="w-4 h-4" />
              <span>Explore Mumbai Like Never Before</span>
            </div>
            
            <h1 className="hero-title">
              <span className="hero-brand">MumbAI Trails</span>
              <span className="hero-tagline">
                Personalized Mumbai trips planned by AI — fast, local, and tailored to you.
              </span>
            </h1>
            
            <div className="hero-actions">
              <Button 
                variant="primary" 
                size="lg"
                onClick={() => navigate('/register')}
              >
                Get Started
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => setIsLoginModalOpen(true)}
              >
                Login
              </Button>
            </div>
          </div>
          
          <div className="hero-image">
            <img 
              src="https://images.pexels.com/photos/3741169/pexels-photo-3741169.jpeg?auto=compress&cs=tinysrgb&w=600"
              alt="Mumbai Gateway of India"
              className="hero-img"
            />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <div className="features-container">
          <h2 className="features-title">Why Choose MumbAI Trails?</h2>
          <div className="features-grid">
            {features.map((feature, index) => (
              <Card key={index} className="feature-card">
                <div className="feature-icon">
                  <feature.icon className="w-8 h-8" />
                </div>
                <h3 className="feature-title">{feature.title}</h3>
                <p className="feature-description">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Search Section */}
      <section className="search-section">
        <div className="search-container">
          <h2 className="search-title">What interests you in Mumbai?</h2>
          <div className="search-bar">
            <Search className="w-6 h-6 text-gray-400" />
            <input
              type="text"
              placeholder="Search Mumbai by interest: food, heritage, beaches"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="search-input"
            />
          </div>
          <div className="search-suggestions">
            {searchSuggestions.map((suggestion, index) => (
              <button
                key={index}
                className="suggestion-tag"
                onClick={() => setSearchQuery(suggestion)}
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Sample Itinerary Section */}
      <section className="sample-section">
        <div className="sample-container">
          <h2 className="sample-title">Sample Mumbai Itinerary</h2>
          <Card className="sample-itinerary">
            <div className="itinerary-header">
              <h3 className="itinerary-title">{sampleItinerary.title}</h3>
              <div className="itinerary-meta">
                <span className="meta-item">
                  <Clock className="w-4 h-4" />
                  1 Day
                </span>
                <span className="meta-item">
                  <MapPin className="w-4 h-4" />
                  5 Places
                </span>
                <span className="meta-item">
                  <Star className="w-4 h-4" />
                  Popular
                </span>
              </div>
            </div>
            
            <div className="itinerary-activities">
              {sampleItinerary.activities.map((activity, index) => (
                <div key={index} className="activity-item">
                  <div className="activity-time">{activity.time}</div>
                  <div className="activity-details">
                    <h4 className="activity-place">{activity.place}</h4>
                    <p className="activity-note">{activity.note}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="itinerary-actions">
              <Button 
                variant="outline" 
                disabled
                className="save-disabled"
              >
                <Save className="w-4 h-4 mr-2" />
                Save (Login Required)
              </Button>
              <Button 
                variant="primary"
                onClick={() => navigate('/register')}
              >
                Create Your Own
              </Button>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="landing-footer">
        <div className="footer-container">
          <div className="footer-brand">
            <MapPin className="w-6 h-6 text-orange-500" />
            <span className="footer-title">MumbAI Trails</span>
          </div>
          <div className="footer-links">
            <a href="#about" className="footer-link">About</a>
            <a href="#contact" className="footer-link">Contact</a>
            <a href="#privacy" className="footer-link">Privacy</a>
            <a href="#terms" className="footer-link">Terms</a>
          </div>
        </div>
      </footer>

      {/* Auth Modal */}
      <AuthModal 
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
      />
    </div>
  );
};