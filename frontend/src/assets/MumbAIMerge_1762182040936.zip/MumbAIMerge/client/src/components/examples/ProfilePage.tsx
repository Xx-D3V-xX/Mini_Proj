import { ProfilePage } from '../ProfilePage';
import { AuthProvider } from '@/contexts/AuthContext';

export default function ProfilePageExample() {
  return (
    <AuthProvider>
      <ProfilePage />
    </AuthProvider>
  );
}
