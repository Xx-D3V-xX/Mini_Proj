import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, MapPin, Clock, Star, Filter, Loader } from 'lucide-react';
import type { Trail } from '@shared/schema';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import heroImage from '@assets/generated_images/Mumbai_Gateway_sunset_hero_a8b398fe.png';
import streetFoodImage from '@assets/generated_images/Mumbai_street_food_scene_93c571de.png';
import heritageImage from '@assets/generated_images/Mumbai_heritage_architecture_CST_2a60e926.png';
import marineDriveImage from '@assets/generated_images/Marine_Drive_sunset_promenade_4a9cf5d9.png';
import natureImage from '@assets/generated_images/Mumbai_nature_trail_forest_843ee3a1.png';
import beachImage from '@assets/generated_images/Juhu_Beach_evening_scene_8613860b.png';

const categories = ['All', 'Food', 'Heritage', 'Beaches', 'Nature', 'Scenic', 'Shopping', 'Entertainment'];
const difficulties = ['All', 'Easy', 'Medium', 'Hard'];

export function ExplorePage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState('All');
  const [sortBy, setSortBy] = useState('rating');

  const { data, isLoading, error } = useQuery<{ trails: Trail[] }>({
    queryKey: ['/api/trails'],
  });

  const trails = data?.trails || [];

  const filteredTrails = trails
    .filter(trail => {
      const matchesSearch = trail.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          trail.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || trail.category === selectedCategory;
      const matchesDifficulty = selectedDifficulty === 'All' || trail.difficulty === selectedDifficulty;
      return matchesSearch && matchesCategory && matchesDifficulty;
    })
    .sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'duration') return parseInt(a.duration) - parseInt(b.duration);
      return 0;
    });

  return (
    <div className="min-h-screen bg-background">
      <section className="relative h-96 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={heroImage}
            alt="Explore Mumbai"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/50" />
        </div>
        
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Explore Mumbai Trails
          </h1>
          <p className="text-xl text-white/90 mb-8">
            Discover curated experiences across the city
          </p>
          
          <div className="max-w-2xl mx-auto backdrop-blur-md bg-white/10 border border-white/30 rounded-full p-2 flex items-center gap-2">
            <Search className="w-5 h-5 text-white ml-3" />
            <Input
              type="search"
              placeholder="Search trails..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-transparent border-0 text-white placeholder:text-white/70 focus-visible:ring-0"
              data-testid="input-search"
            />
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex flex-col md:flex-row gap-6 mb-12">
          <div className="flex-1 flex flex-wrap gap-3">
            <Badge variant="outline" className="text-sm px-3 py-2">
              <Filter className="w-4 h-4 mr-2" />
              Filters
            </Badge>
            {categories.map((category) => (
              <Badge
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                className="cursor-pointer hover-elevate active-elevate-2 px-3 py-2"
                onClick={() => setSelectedCategory(category)}
                data-testid={`badge-category-${category.toLowerCase()}`}
              >
                {category}
              </Badge>
            ))}
          </div>

          <div className="flex gap-3">
            <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
              <SelectTrigger className="w-40" data-testid="select-difficulty">
                <SelectValue placeholder="Difficulty" />
              </SelectTrigger>
              <SelectContent>
                {difficulties.map((difficulty) => (
                  <SelectItem key={difficulty} value={difficulty}>
                    {difficulty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40" data-testid="select-sort">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="duration">Shortest First</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader className="w-8 h-8 animate-spin text-primary" data-testid="loader-trails" />
          </div>
        ) : error ? (
          <Card className="p-12 text-center">
            <p className="text-destructive">Failed to load trails. Please try again later.</p>
          </Card>
        ) : filteredTrails.length === 0 ? (
          <Card className="p-12 text-center">
            <Search className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No trails found</h3>
            <p className="text-muted-foreground">
              Try adjusting your filters or search query
            </p>
          </Card>
        ) : (
          <>
            <div className="mb-6 text-sm text-muted-foreground">
              Showing {filteredTrails.length} {filteredTrails.length === 1 ? 'trail' : 'trails'}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTrails.map((trail) => (
                <Card key={trail.id} className="overflow-hidden hover-elevate active-elevate-2 cursor-pointer" data-testid={`card-trail-${trail.id}`}>
                  <div className="relative h-48">
                    <img src={trail.image} alt={trail.title} className="w-full h-full object-cover" />
                    <Badge className="absolute top-4 right-4" data-testid={`badge-difficulty-${trail.id}`}>
                      {trail.difficulty}
                    </Badge>
                    <Badge variant="secondary" className="absolute top-4 left-4" data-testid={`badge-category-${trail.id}`}>
                      {trail.category}
                    </Badge>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2">{trail.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{trail.description}</p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {trail.duration}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {trail.distance}
                      </span>
                      <span className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-current text-yellow-500" />
                        {trail.rating}
                      </span>
                    </div>
                    <Button className="w-full" data-testid={`button-view-${trail.id}`}>
                      View Details
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
