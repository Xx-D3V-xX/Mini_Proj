import { LandingPage } from '../LandingPage';
import { AuthProvider } from '@/contexts/AuthContext';

export default function LandingPageExample() {
  return (
    <AuthProvider>
      <LandingPage />
    </AuthProvider>
  );
}
