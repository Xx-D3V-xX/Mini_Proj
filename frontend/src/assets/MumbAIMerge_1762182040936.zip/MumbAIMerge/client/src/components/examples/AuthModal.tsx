import { useState } from 'react';
import { AuthModal } from '../AuthModal';
import { AuthProvider } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';

export default function AuthModalExample() {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <AuthProvider>
      <div className="min-h-screen flex items-center justify-center bg-background p-6">
        <Button onClick={() => setIsOpen(true)}>Open Auth Modal</Button>
        <AuthModal isOpen={isOpen} onClose={() => setIsOpen(false)} />
      </div>
    </AuthProvider>
  );
}
