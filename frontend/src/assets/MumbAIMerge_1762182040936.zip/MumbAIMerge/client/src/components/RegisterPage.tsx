import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { MapPin, Loader, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

const availableInterests = [
  'Food & Dining',
  'Heritage Sites',
  'Beaches',
  'Nature Trails',
  'Nightlife',
  'Shopping',
  'Art & Culture',
  'Bollywood',
  'Photography',
  'Adventure Sports'
];

export function RegisterPage() {
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  const { register } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleStep1Submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      toast({
        title: 'Passwords do not match',
        description: 'Please make sure your passwords match.',
        variant: 'destructive',
      });
      return;
    }
    setStep(2);
  };

  const toggleInterest = (interest: string) => {
    setSelectedInterests(prev => 
      prev.includes(interest) 
        ? prev.filter(i => i !== interest)
        : [...prev, interest]
    );
  };

  const handleFinalSubmit = async () => {
    if (selectedInterests.length === 0) {
      toast({
        title: 'Select at least one interest',
        description: 'Please select at least one interest to continue.',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      await register({ name, username, email, password, interests: selectedInterests });
      toast({
        title: 'Welcome to MumbAI Trails!',
        description: 'Your account has been created successfully.',
      });
      setLocation('/explore');
    } catch (err: any) {
      toast({
        title: 'Registration failed',
        description: err.message || 'Something went wrong. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <Card className="w-full max-w-2xl p-8">
        <div className="mb-8">
          <Link href="/">
            <button className="flex items-center gap-2 mb-6 text-primary hover:underline" data-testid="link-back">
              <MapPin className="w-5 h-5" />
              <span className="font-semibold">MumbAI Trails</span>
            </button>
          </Link>
          
          <h1 className="text-3xl font-bold mb-2">
            {step === 1 ? 'Create Your Account' : 'Tell Us Your Interests'}
          </h1>
          <p className="text-muted-foreground">
            {step === 1 
              ? 'Start exploring Mumbai with personalized recommendations' 
              : 'Help us personalize your Mumbai experience'}
          </p>
        </div>

        {step === 1 ? (
          <form onSubmit={handleStep1Submit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your full name"
                required
                data-testid="input-name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Choose a username"
                required
                minLength={3}
                data-testid="input-username"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                required
                data-testid="input-email"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Create a password"
                required
                minLength={6}
                data-testid="input-password"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <Input
                id="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm your password"
                required
                minLength={6}
                data-testid="input-confirm-password"
              />
            </div>

            <Button type="submit" className="w-full" data-testid="button-continue">
              Continue
            </Button>

            <div className="text-center text-sm text-muted-foreground">
              Already have an account?{' '}
              <Link href="/">
                <button className="text-primary hover:underline font-medium" data-testid="link-login">
                  Login
                </button>
              </Link>
            </div>
          </form>
        ) : (
          <div className="space-y-6">
            <p className="text-sm text-muted-foreground">
              Select your interests (you can select multiple)
            </p>
            
            <div className="grid grid-cols-2 gap-3">
              {availableInterests.map((interest) => (
                <Badge
                  key={interest}
                  variant={selectedInterests.includes(interest) ? 'default' : 'outline'}
                  className="p-4 cursor-pointer hover-elevate active-elevate-2 justify-center text-center"
                  onClick={() => toggleInterest(interest)}
                  data-testid={`badge-interest-${interest.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {selectedInterests.includes(interest) && (
                    <CheckCircle className="w-4 h-4 mr-2" />
                  )}
                  {interest}
                </Badge>
              ))}
            </div>

            <div className="flex gap-4">
              <Button
                variant="outline"
                onClick={() => setStep(1)}
                className="flex-1"
                data-testid="button-back"
              >
                Back
              </Button>
              <Button
                onClick={handleFinalSubmit}
                disabled={isLoading || selectedInterests.length === 0}
                className="flex-1"
                data-testid="button-complete"
              >
                {isLoading ? (
                  <>
                    <Loader className="w-5 h-5 mr-2 animate-spin" />
                    Creating Account...
                  </>
                ) : (
                  'Complete Registration'
                )}
              </Button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
