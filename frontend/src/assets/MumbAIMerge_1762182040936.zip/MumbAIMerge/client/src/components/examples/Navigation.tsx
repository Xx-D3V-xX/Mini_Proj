import { Navigation } from '../Navigation';
import { AuthProvider } from '@/contexts/AuthContext';

export default function NavigationExample() {
  return (
    <AuthProvider>
      <Navigation />
      <div className="p-6">
        <h1 className="text-3xl font-bold mb-4">Navigation Component</h1>
        <p className="text-muted-foreground">
          This is a demonstration of the navigation component. Try logging in to see the user menu.
        </p>
      </div>
    </AuthProvider>
  );
}
