import { ExplorePage } from '../ExplorePage';

export default function ExplorePageExample() {
  return <ExplorePage />;
}
