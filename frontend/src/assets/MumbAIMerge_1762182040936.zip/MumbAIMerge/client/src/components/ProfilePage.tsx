import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { User as UserIcon, Settings, Calendar, MapPin, Download, Trash2, Edit, Eye, Share2, Loader } from 'lucide-react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import type { Itinerary, VisitHistory } from '@shared/schema';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/AuthContext';
import { Link, useLocation } from 'wouter';

export function ProfilePage() {
  const { user, logout, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState('itineraries');
  const [expandedItinerary, setExpandedItinerary] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      setLocation('/');
    }
  }, [authLoading, user, setLocation]);

  const { data: itinerariesData, isLoading: itinerariesLoading } = useQuery<{ itineraries: Itinerary[] }>({
    queryKey: ['/api/itineraries'],
    enabled: !!user,
  });

  const { data: historyData, isLoading: historyLoading } = useQuery<{ history: VisitHistory[] }>({
    queryKey: ['/api/history'],
    enabled: !!user,
  });

  const deleteItineraryMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest(`/api/itineraries/${id}`, 'DELETE');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/itineraries'] });
    },
  });

  const itineraries = itinerariesData?.itineraries || [];
  const history = historyData?.history || [];
  const isLoading = itinerariesLoading || historyLoading;

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const handleDeleteItinerary = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this itinerary?')) {
      deleteItineraryMutation.mutate(id);
    }
  };

  const handleExportItinerary = (itinerary: Itinerary) => {
    const dataStr = JSON.stringify(itinerary, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${itinerary.title.replace(/\s+/g, '_')}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleLogout = () => {
    logout();
    setLocation('/');
  };

  return (
    <div className="min-h-screen bg-background py-12 px-6">
      <div className="max-w-6xl mx-auto">
        <Card className="p-8 mb-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="flex items-start gap-6">
              <Avatar className="w-24 h-24">
                <AvatarImage src={user.avatarUrl} alt={user.name} />
                <AvatarFallback className="text-2xl">
                  <UserIcon className="w-12 h-12" />
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h1 className="text-3xl font-bold mb-2">{user.name}</h1>
                <p className="text-muted-foreground mb-4">{user.email}</p>
                <div className="flex flex-wrap gap-2">
                  {user.interests.map((interest, index) => (
                    <Badge key={index} variant="secondary" data-testid={`badge-interest-${index}`}>
                      {interest}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" size="sm" data-testid="button-edit-profile">
                <Edit className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
              <Button variant="outline" size="sm" onClick={handleLogout} data-testid="button-logout">
                Logout
              </Button>
            </div>
          </div>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="itineraries" data-testid="tab-itineraries">
              <Calendar className="w-5 h-5 mr-2" />
              My Itineraries
            </TabsTrigger>
            <TabsTrigger value="history" data-testid="tab-history">
              <MapPin className="w-5 h-5 mr-2" />
              Places Visited
            </TabsTrigger>
            <TabsTrigger value="preferences" data-testid="tab-preferences">
              <Settings className="w-5 h-5 mr-2" />
              Preferences
            </TabsTrigger>
          </TabsList>

          <TabsContent value="itineraries" className="space-y-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-semibold">My Itineraries</h2>
                <p className="text-muted-foreground">{itineraries.length} saved itineraries</p>
              </div>
            </div>

            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : itineraries.length === 0 ? (
              <Card className="p-12 text-center">
                <Calendar className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No itineraries yet</h3>
                <p className="text-muted-foreground mb-6">
                  You don't have any saved itineraries yet — explore Mumbai and save your first trip!
                </p>
                <Link href="/explore">
                  <Button data-testid="button-create-itinerary">Create Itinerary</Button>
                </Link>
              </Card>
            ) : (
              <div className="space-y-6">
                {itineraries.map((itinerary) => (
                  <Card key={itinerary.id} className="p-6" data-testid={`card-itinerary-${itinerary.id}`}>
                    <div className="flex flex-col md:flex-row justify-between gap-6 mb-4">
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold mb-2">{itinerary.title}</h3>
                        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-3">
                          <span>Created {itinerary.createdAt ? new Date(itinerary.createdAt).toLocaleDateString() : 'Unknown'}</span>
                          <span>{itinerary.days} days • {itinerary.poisCount} places</span>
                        </div>
                        <p className="text-muted-foreground">{itinerary.summary}</p>
                      </div>
                      <div className="flex flex-wrap gap-2 items-start">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setExpandedItinerary(
                            expandedItinerary === itinerary.id ? null : itinerary.id
                          )}
                          data-testid={`button-view-${itinerary.id}`}
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          {expandedItinerary === itinerary.id ? 'Hide' : 'View'}
                        </Button>
                        <Button variant="outline" size="sm" data-testid={`button-edit-${itinerary.id}`}>
                          <Edit className="w-4 h-4 mr-1" />
                          Edit
                        </Button>
                        <Button variant="outline" size="sm" data-testid={`button-share-${itinerary.id}`}>
                          <Share2 className="w-4 h-4 mr-1" />
                          Share
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleExportItinerary(itinerary)}
                          data-testid={`button-export-${itinerary.id}`}
                        >
                          <Download className="w-4 h-4 mr-1" />
                          Export
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteItinerary(itinerary.id)}
                          data-testid={`button-delete-${itinerary.id}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    {expandedItinerary === itinerary.id && (
                      <div className="mt-6 pt-6 border-t">
                        <h4 className="font-semibold mb-4">Itinerary Details</h4>
                        <div className="space-y-4">
                          {Array.isArray(itinerary.items) && (itinerary.items as any[]).map((item: any, index: number) => (
                            <div key={index} className="flex gap-6 pb-4 border-b last:border-0" data-testid={`item-${index}`}>
                              <div className="text-sm font-medium text-muted-foreground min-w-16">Day {item.day}</div>
                              <div className="flex-1">
                                <h5 className="font-semibold mb-1">{item.place}</h5>
                                <p className="text-sm text-muted-foreground">{item.description}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-semibold">Places Visited</h2>
                <p className="text-muted-foreground">{history.length} places</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" data-testid="button-download-history">
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </div>
            </div>

            {history.length === 0 ? (
              <Card className="p-12 text-center">
                <MapPin className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No places visited yet</h3>
                <p className="text-muted-foreground">
                  Start exploring Mumbai and your visit history will appear here!
                </p>
              </Card>
            ) : (
              <div className="grid gap-4">
                {history.map((item) => (
                  <Card key={item.id} className="p-6" data-testid={`card-history-${item.id}`}>
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg mb-2">{item.placeName}</h3>
                        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-2">
                          <span>Visited {new Date(item.visitDate).toLocaleDateString()}</span>
                          {item.bookingId && <span>Booking: {item.bookingId}</span>}
                        </div>
                        {item.notes && (
                          <p className="text-muted-foreground mt-2">{item.notes}</p>
                        )}
                      </div>
                      {item.rating && (
                        <div className="flex gap-1">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <span
                              key={star}
                              className={`text-xl ${star <= item.rating! ? 'text-yellow-500' : 'text-gray-300'}`}
                            >
                              ★
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="preferences" className="space-y-6">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold mb-2">Travel Preferences</h2>
              <p className="text-muted-foreground">Customize your Mumbai experience</p>
            </div>

            <div className="grid gap-6">
              <Card className="p-6">
                <h3 className="font-semibold text-lg mb-4">Interests</h3>
                <div className="flex flex-wrap gap-2 mb-4">
                  {user.interests.map((interest, index) => (
                    <Badge key={index} variant="secondary">
                      {interest}
                    </Badge>
                  ))}
                </div>
                <Button variant="outline" size="sm" data-testid="button-edit-interests">
                  Edit Interests
                </Button>
              </Card>

              <Card className="p-6">
                <h3 className="font-semibold text-lg mb-4">Budget Range</h3>
                <div className="space-y-4">
                  <Input
                    type="range"
                    min="1000"
                    max="10000"
                    defaultValue="5000"
                    className="w-full"
                    data-testid="input-budget"
                  />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>₹1,000</span>
                    <span>₹10,000</span>
                  </div>
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="font-semibold text-lg mb-4">Travel Mode</h3>
                <div className="space-y-3">
                  {['Walking', 'Public Transport', 'Taxi', 'Auto Rickshaw'].map((mode) => (
                    <div key={mode} className="flex items-center space-x-2">
                      <Checkbox id={mode} defaultChecked data-testid={`checkbox-${mode.toLowerCase().replace(/\s+/g, '-')}`} />
                      <Label htmlFor={mode}>{mode}</Label>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
