import { RegisterPage } from '../RegisterPage';
import { AuthProvider } from '@/contexts/AuthContext';

export default function RegisterPageExample() {
  return (
    <AuthProvider>
      <RegisterPage />
    </AuthProvider>
  );
}
