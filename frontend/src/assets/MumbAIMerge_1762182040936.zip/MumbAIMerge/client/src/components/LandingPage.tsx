import { useState } from 'react';
import { Link } from 'wouter';
import { MapPin, Zap, Cloud, Save, Search, Clock, Star, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { AuthModal } from '@/components/AuthModal';
import heroImage from '@assets/generated_images/Mumbai_Gateway_sunset_hero_a8b398fe.png';
import streetFoodImage from '@assets/generated_images/Mumbai_street_food_scene_93c571de.png';
import heritageImage from '@assets/generated_images/Mumbai_heritage_architecture_CST_2a60e926.png';
import marineDriveImage from '@assets/generated_images/Marine_Drive_sunset_promenade_4a9cf5d9.png';
import natureImage from '@assets/generated_images/Mumbai_nature_trail_forest_843ee3a1.png';
import beachImage from '@assets/generated_images/Juhu_Beach_evening_scene_8613860b.png';
import traveler1Image from '@assets/generated_images/Happy_Mumbai_traveler_portrait_8aaffc1d.png';
import traveler2Image from '@assets/generated_images/Couple_enjoying_Mumbai_food_c30a7790.png';

export function LandingPage() {
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const features = [
    {
      icon: Zap,
      title: 'AI Recommendations',
      description: 'Get personalized itineraries based on your mood, budget, and interests'
    },
    {
      icon: Cloud,
      title: 'Real-time Weather & Maps',
      description: 'Live weather updates and optimized routes for your Mumbai adventure'
    },
    {
      icon: Save,
      title: 'Save & Revisit Itineraries',
      description: 'Save your favorite trips and share them with friends via QR codes'
    }
  ];

  const categories = [
    { name: 'Street Food', image: streetFoodImage, count: '150+ spots' },
    { name: 'Heritage Sites', image: heritageImage, count: '75+ locations' },
    { name: 'Beaches', image: beachImage, count: '25+ beaches' },
    { name: 'Nature Trails', image: natureImage, count: '40+ trails' }
  ];

  const trailCards = [
    { title: 'Mumbai Food Trail', image: streetFoodImage, difficulty: 'Easy', duration: '3 hours', rating: 4.8 },
    { title: 'Heritage Walk', image: heritageImage, difficulty: 'Medium', duration: '4 hours', rating: 4.9 },
    { title: 'Marine Drive Evening', image: marineDriveImage, difficulty: 'Easy', duration: '2 hours', rating: 4.7 },
    { title: 'Beach Hopping', image: beachImage, difficulty: 'Easy', duration: '5 hours', rating: 4.6 },
    { title: 'Nature Explorer', image: natureImage, difficulty: 'Hard', duration: '6 hours', rating: 4.8 },
    { title: 'Gateway Tour', image: heroImage, difficulty: 'Easy', duration: '2 hours', rating: 4.9 }
  ];

  const testimonials = [
    {
      name: 'Priya Sharma',
      image: traveler1Image,
      quote: 'MumbAI Trails helped me discover hidden gems I never knew existed. The personalized itinerary was perfect for my weekend trip!',
      verified: true
    },
    {
      name: 'Raj & Meera',
      image: traveler2Image,
      quote: 'We loved the food tour! Every recommendation was spot-on. Made our honeymoon in Mumbai unforgettable.',
      verified: true
    }
  ];

  const searchSuggestions = ['Street food tours', 'Heritage walks', 'Beach activities', 'Bollywood experiences', 'Night markets', 'Art galleries'];

  //todo: remove mock functionality
  const sampleItinerary = {
    title: '1-Day Food & Sunset: Colaba to Marine Drive',
    activities: [
      { time: '9:00 AM', place: 'Leopold Cafe', note: 'Breakfast & coffee' },
      { time: '11:00 AM', place: 'Crawford Market', note: 'Local shopping experience' },
      { time: '1:00 PM', place: 'Mohammed Ali Road', note: 'Street food tour' },
      { time: '4:00 PM', place: 'Gateway of India', note: 'Historic landmark' },
      { time: '6:00 PM', place: 'Marine Drive', note: 'Sunset viewing' }
    ]
  };

  return (
    <div className="min-h-screen bg-background">
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={heroImage}
            alt="Mumbai Gateway of India"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/60" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-6 text-center">
          <Badge variant="secondary" className="mb-8 backdrop-blur-md bg-white/20 border-white/30 text-white" data-testid="badge-hero">
            <MapPin className="w-4 h-4" />
            Explore Mumbai Like Never Before
          </Badge>
          
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight">
            <span className="block font-serif mb-2">MumbAI Trails</span>
            <span className="block text-2xl md:text-4xl font-normal text-white/90">
              Personalized Mumbai trips planned by AI — fast, local, and tailored to you.
            </span>
          </h1>
          
          <div className="flex flex-wrap gap-4 justify-center items-center mt-12">
            <Link href="/explore" data-testid="link-explore">
              <Button size="lg" className="min-h-12 px-8 backdrop-blur-md" data-testid="button-get-started">
                Get Started
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => setIsLoginModalOpen(true)}
              className="min-h-12 px-8 backdrop-blur-md bg-white/10 border-white/30 text-white hover:bg-white/20"
              data-testid="button-login"
            >
              Login
            </Button>
          </div>

          <div className="mt-12 max-w-2xl mx-auto">
            <div className="relative backdrop-blur-md bg-white/10 border border-white/30 rounded-full p-2 flex items-center gap-2">
              <Search className="w-5 h-5 text-white ml-3" />
              <Input
                type="search"
                placeholder="Search trails, locations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent border-0 text-white placeholder:text-white/70 focus-visible:ring-0"
                data-testid="input-search"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-semibold text-center mb-16">Why Choose MumbAI Trails?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="p-8 hover-elevate active-elevate-2" data-testid={`card-feature-${index}`}>
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-6">
                  <feature.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 px-6 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-semibold text-center mb-6">Featured Trails</h2>
          <p className="text-center text-muted-foreground mb-16 text-lg">Discover popular experiences curated by locals</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trailCards.map((trail, index) => (
              <Card key={index} className="overflow-hidden hover-elevate active-elevate-2 cursor-pointer" data-testid={`card-trail-${index}`}>
                <div className="relative h-48">
                  <img src={trail.image} alt={trail.title} className="w-full h-full object-cover" />
                  <Badge className="absolute top-4 right-4" data-testid={`badge-difficulty-${index}`}>
                    {trail.difficulty}
                  </Badge>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-3">{trail.title}</h3>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {trail.duration}
                    </span>
                    <span className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-current text-yellow-500" />
                      {trail.rating}
                    </span>
                  </div>
                </div>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link href="/explore">
              <Button variant="outline" size="lg" data-testid="button-view-all">
                View All Trails
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-semibold text-center mb-16">Explore by Category</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category, index) => (
              <Card key={index} className="relative h-64 overflow-hidden group cursor-pointer hover-elevate active-elevate-2" data-testid={`card-category-${index}`}>
                <img src={category.image} alt={category.name} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <h3 className="text-2xl font-semibold mb-1">{category.name}</h3>
                  <p className="text-white/80">{category.count}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 px-6 bg-muted/30">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-semibold text-center mb-6">What interests you in Mumbai?</h2>
          <p className="text-center text-muted-foreground mb-12 text-lg">Quick search by your interests</p>
          
          <div className="flex flex-wrap gap-3 justify-center mb-8">
            {searchSuggestions.map((suggestion, index) => (
              <Badge
                key={index}
                variant="secondary"
                className="px-4 py-2 cursor-pointer hover-elevate active-elevate-2"
                onClick={() => setSearchQuery(suggestion)}
                data-testid={`badge-suggestion-${index}`}
              >
                {suggestion}
              </Badge>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-semibold text-center mb-16">Sample Mumbai Itinerary</h2>
          <Card className="p-8" data-testid="card-sample-itinerary">
            <div className="mb-8">
              <h3 className="text-2xl font-semibold mb-4">{sampleItinerary.title}</h3>
              <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  1 Day
                </span>
                <span className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  5 Places
                </span>
                <Badge variant="secondary" data-testid="badge-popular">
                  <Star className="w-4 h-4 mr-1 fill-current text-yellow-500" />
                  Popular
                </Badge>
              </div>
            </div>
            
            <div className="space-y-4 mb-8">
              {sampleItinerary.activities.map((activity, index) => (
                <div key={index} className="flex gap-6 pb-4 border-b last:border-0" data-testid={`activity-${index}`}>
                  <div className="text-sm font-medium text-muted-foreground min-w-20">{activity.time}</div>
                  <div className="flex-1">
                    <h4 className="font-semibold mb-1">{activity.place}</h4>
                    <p className="text-sm text-muted-foreground">{activity.note}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex flex-wrap gap-4 justify-end">
              <Button 
                variant="outline" 
                disabled
                className="opacity-60"
                data-testid="button-save-disabled"
              >
                <Save className="w-4 h-4 mr-2" />
                Save (Login Required)
              </Button>
              <Link href="/explore">
                <Button data-testid="button-create-own">
                  Create Your Own
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
            </div>
          </Card>
        </div>
      </section>

      <section className="py-24 px-6 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-semibold text-center mb-16">What Travelers Say</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="p-8" data-testid={`card-testimonial-${index}`}>
                <div className="flex items-start gap-4 mb-4">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-semibold">{testimonial.name}</h4>
                      {testimonial.verified && (
                        <Badge variant="secondary" className="text-xs" data-testid={`badge-verified-${index}`}>
                          Verified
                        </Badge>
                      )}
                    </div>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star key={star} className="w-4 h-4 fill-current text-yellow-500" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-muted-foreground leading-relaxed italic">"{testimonial.quote}"</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="relative py-32 px-6 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src={marineDriveImage} alt="Newsletter background" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black/70" />
        </div>
        <div className="relative z-10 max-w-3xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Stay Updated on Mumbai's Best</h2>
          <p className="text-xl text-white/90 mb-8">Weekly trail recommendations and exclusive local insights</p>
          <div className="flex gap-4 max-w-md mx-auto">
            <Input 
              type="email" 
              placeholder="Enter your email"
              className="flex-1 bg-white/10 backdrop-blur-md border-white/30 text-white placeholder:text-white/70"
              data-testid="input-newsletter"
            />
            <Button size="lg" data-testid="button-subscribe">
              Subscribe
            </Button>
          </div>
        </div>
      </section>

      <footer className="py-16 px-6 border-t">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <MapPin className="w-6 h-6 text-primary" />
                <span className="text-xl font-semibold">MumbAI Trails</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Discover Mumbai like never before with AI-powered personalized itineraries.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">About MumbAI</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#about" className="hover:text-foreground transition-colors">About Us</a></li>
                <li><a href="#team" className="hover:text-foreground transition-colors">Our Team</a></li>
                <li><a href="#blog" className="hover:text-foreground transition-colors">Blog</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/explore" className="hover:text-foreground transition-colors">Explore Trails</Link></li>
                <li><a href="#categories" className="hover:text-foreground transition-colors">Categories</a></li>
                <li><a href="#popular" className="hover:text-foreground transition-colors">Popular Trails</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#contact" className="hover:text-foreground transition-colors">Contact</a></li>
                <li><a href="#privacy" className="hover:text-foreground transition-colors">Privacy Policy</a></li>
                <li><a href="#terms" className="hover:text-foreground transition-colors">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          <div className="pt-8 border-t text-center text-sm text-muted-foreground">
            <p>&copy; 2025 MumbAI Trails. All rights reserved.</p>
          </div>
        </div>
      </footer>

      <AuthModal 
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
      />
    </div>
  );
}
