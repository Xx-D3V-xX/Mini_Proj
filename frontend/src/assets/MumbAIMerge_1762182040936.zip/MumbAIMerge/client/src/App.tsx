import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { Navigation } from "@/components/Navigation";
import { LandingPage } from "@/components/LandingPage";
import { RegisterPage } from "@/components/RegisterPage";
import { ProfilePage } from "@/components/ProfilePage";
import { ExplorePage } from "@/components/ExplorePage";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/register" component={RegisterPage} />
      <Route path="/profile" component={ProfilePageWithNav} />
      <Route path="/explore" component={ExplorePageWithNav} />
      <Route component={NotFound} />
    </Switch>
  );
}

function ProfilePageWithNav() {
  return (
    <>
      <Navigation />
      <ProfilePage />
    </>
  );
}

function ExplorePageWithNav() {
  return (
    <>
      <Navigation />
      <ExplorePage />
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Router />
          <Toaster />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
