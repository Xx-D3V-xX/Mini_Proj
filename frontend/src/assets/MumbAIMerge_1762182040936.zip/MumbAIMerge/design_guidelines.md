# MumbAI Trails - Design Guidelines

## Design Approach

**Selected Approach:** Reference-Based (Travel & Experience Platforms)

**Primary References:** Airbnb (hospitality & experiences), AllTrails (outdoor experiences), Booking.com (discovery & navigation)

**Design Philosophy:** Create an immersive, visually-driven experience that showcases Mumbai's trails through stunning imagery while maintaining intuitive navigation and seamless user flows between discovery, authentication, and personalized features.

---

## Typography System

**Font Stack:**
- **Primary (Headings):** Inter (Google Fonts) - 600, 700, 800 weights
- **Secondary (Body):** Inter - 400, 500 weights
- **Accent (Special Features):** Playfair Display - 600 weight for hero taglines only

**Hierarchy:**
- Hero Headlines: text-5xl to text-7xl, font-bold tracking-tight
- Section Headers: text-3xl to text-4xl, font-semibold
- Card Titles: text-xl to text-2xl, font-semibold
- Body Text: text-base to text-lg, font-normal leading-relaxed
- Captions/Meta: text-sm, font-medium

---

## Layout System

**Spacing Primitives:** Use Tailwind units of 4, 6, 8, 12, 16, 20, 24
- Component padding: p-4 (mobile), p-8 (desktop)
- Section spacing: py-16 to py-24
- Grid gaps: gap-6 to gap-8
- Card spacing: p-6 to p-8

**Container Strategy:**
- Full-width sections: w-full with max-w-7xl mx-auto px-6
- Content sections: max-w-6xl mx-auto
- Text-heavy content: max-w-4xl mx-auto

**Grid System:**
- Trail Cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Featured Trails: grid-cols-1 lg:grid-cols-2 (larger cards)
- Profile Dashboard: grid-cols-1 md:grid-cols-3 (stats/info split)

---

## Component Library

### Navigation
**Global Header:**
- Sticky top navigation with backdrop blur
- Logo left, navigation center, profile/login right
- Mobile: Hamburger menu with slide-in drawer
- Items: Home, Explore Trails, Categories, About, Profile/Login
- Include search bar in header for trail discovery

**Footer:**
- Four-column layout: About MumbAI, Quick Links, Popular Trails, Newsletter Signup
- Social media icons
- Copyright and trust indicators ("Verified Trails," "Local Guides")

### Landing Page Structure

**Hero Section (100vh):**
- Full-screen background: Stunning Mumbai trail/cityscape image
- Centered content overlay with backdrop-blur background for text container
- Headline: "Discover Mumbai's Hidden Trails" (text-6xl)
- Subheadline: Descriptive tagline (text-xl)
- Dual CTAs: "Start Exploring" (primary), "Learn More" (secondary with blur background)
- Floating search bar below CTAs: Location/Trail type/Difficulty filters

**Featured Trails Section:**
- Grid of 6-9 trail cards with hover lift effect
- Each card: Large image, trail name, difficulty badge, duration, rating stars
- "View All Trails" button at bottom

**Categories Section:**
- 3-4 column grid showcasing trail types (Coastal, Heritage, Nature, Urban)
- Icon + title + count format with background images

**How It Works:**
- 3-step process cards (horizontal on desktop)
- Icons, titles, descriptions for: Discover → Plan → Experience

**Testimonials:**
- 2-column grid with user photos, quotes, names, verification badges
- Authentic traveler experiences

**Newsletter CTA:**
- Full-width section with background image overlay
- Headline, email input, subscribe button inline
- Promise: "Weekly trail recommendations"

### Trail Listing & Detail Pages

**Trail Cards:**
- Rounded corners (rounded-2xl)
- Image with gradient overlay for readability
- Difficulty badge (absolute positioned, top-right)
- Title, location, duration, rating, price (if applicable)
- Quick stats row with icons (distance, elevation, time)
- "Save" heart icon button

**Trail Detail Page:**
- Hero image gallery (main + 4 thumbnails, lightbox functionality)
- Sticky booking/action sidebar on desktop
- Tabs: Overview, Route Map, Reviews, Photos
- Route map integration (placeholder for Google Maps/Mapbox)
- Review section with star ratings, photos, verified badges

### Authentication

**Login/Signup Modal:**
- Centered modal with backdrop blur
- Tabbed interface (Login | Sign Up)
- Social login options (Google, Facebook) + divider
- Email/password fields with show/hide toggle
- "Forgot Password?" link, "Remember Me" checkbox
- Close button (X) top-right

**Profile Page:**
- Split layout: Sidebar (avatar, name, edit profile) + Main content area
- Tabs: Saved Trails, Completed Trails, Reviews, Settings
- Activity stats cards: Trails Completed, Distance Covered, Reviews Written
- Grid of saved/completed trails matching card design

### Forms & Inputs

**Search Bar:**
- Rounded full (rounded-full), shadow-lg
- Magnifying glass icon left, filters dropdown right
- Placeholder: "Search trails, locations..."
- Autocomplete suggestions dropdown

**Input Fields:**
- Rounded-lg borders, focus ring styling
- Label above, helper text below
- Icon support (left positioned)
- Error states with red accent

**Buttons:**
- Primary: Solid with hover scale transform, rounded-lg, px-8 py-3
- Secondary: Outline style, same sizing
- Icon buttons: Square with rounded-lg, p-3
- CTAs on images: Backdrop blur background (backdrop-blur-md bg-white/20)

### Cards & Content Blocks

**Trail Cards:** Elevation on hover (shadow-lg to shadow-2xl transition), rounded-2xl, overflow-hidden for images

**Info Cards:** Glass morphism effect for stats (backdrop-blur-sm bg-white/10), border subtle

**Category Cards:** Large background images with gradient overlays, centered content

---

## Images

**Critical Image Placements:**

1. **Landing Hero (Required):** Full-width, high-quality Mumbai landscape/trail scene - iconic Gateway of India at sunset with urban trails, or lush Sanjay Gandhi National Park trail view. Should evoke adventure and discovery.

2. **Featured Trail Cards (6-9 images):** Diverse trail photos - coastal paths, heritage walks, nature trails, urban exploration. Each should be vibrant and inviting.

3. **Category Section (4 images):** Representative images for each trail type - beach/coastal, historic monuments, forest/nature, city skyline.

4. **Testimonial Section (2-3 images):** Authentic traveler photos (diverse, happy people on trails).

5. **Newsletter CTA Background:** Subtle Mumbai cityscape or trail scene with overlay.

6. **Trail Detail Pages:** Gallery of 5+ images per trail showing different angles, landmarks, and experiences.

**Image Treatment:** All images should use object-cover, aspect ratios of 16:9 for heroes, 4:3 for cards, rounded corners matching component style.

---

## Interactions & Animations

**Minimal Animation Strategy:**
- Card hover: Translate Y (-4px) + shadow enhancement (300ms ease)
- Button hover: Scale (1.02) + subtle shadow (200ms ease)
- Modal entrance: Fade + scale from 0.95 (300ms ease-out)
- Page transitions: Fade only (200ms)
- No scroll-based animations except gentle parallax on hero (if any)

---

## Accessibility & Best Practices

- Maintain 4.5:1 contrast ratio for all text on images (use overlays/blurs)
- All interactive elements have focus states (ring-2 ring-offset-2)
- Form inputs have visible labels and error messages
- Alt text for all trail images
- Keyboard navigation support throughout
- ARIA labels for icon-only buttons

---

## Key Design Principles

1. **Image-First:** Let stunning photography drive engagement and inspire exploration
2. **Clear Hierarchy:** Information architecture mirrors user journey (Discover → Explore → Book/Save → Experience)
3. **Trust Signals:** Verified badges, ratings, user photos build credibility
4. **Seamless Auth:** Login/profile integrated naturally without disrupting exploration
5. **Mobile Excellence:** Touch-friendly targets (minimum 44px), optimized imagery, simplified navigation